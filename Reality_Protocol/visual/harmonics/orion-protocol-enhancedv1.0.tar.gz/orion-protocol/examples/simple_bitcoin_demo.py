#!/usr/bin/env python3
"""
Simple Bitcoin Demo for Orion Protocol

This is the simplest possible example - it shows how Bitcoin price
changes turn into boxer animations. Perfect for understanding the basics.

Run this file to see Orion Protocol in action!
"""

import sys
import os
import time

# Add the src directory to the path so we can import orion_core
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from orion_core import OrionProtocol, BitcoinPriceSource

def print_boxer_animation(animation_type, intensity):
    """
    Print ASCII art showing the boxer animation
    
    This is just for demonstration - in a real app, this would be
    3D graphics or video animations.
    """
    boxer_art = {
        "idle": [
            "    🥊",
            "   /|\\",
            "    |",
            "   / \\"
        ],
        "jab": [
            "  🥊  →",
            "   /|",
            "    |",
            "   / \\"
        ],
        "cross": [
            "    🥊",
            " ← /|\\  →",
            "    |",
            "   / \\"
        ],
        "hook": [
            "    🥊",
            "   /|↗",
            "    |",
            "   / \\"
        ],
        "uppercut": [
            "    🥊↑",
            "   /|\\",
            "    |",
            "   / \\"
        ]
    }
    
    art = boxer_art.get(animation_type, boxer_art["idle"])
    
    print(f"\n{animation_type.upper()} - Power: {intensity:.0%}")
    for line in art:
        print(f"  {line}")
    print()

def main():
    print("🥊 BITCOIN BOXER - Simple Demo")
    print("=" * 40)
    print("Watch the boxer react to Bitcoin price changes!")
    print("(Press Ctrl+C to stop)\n")
    
    # Create the Orion system and Bitcoin data source
    orion = OrionProtocol()
    bitcoin = BitcoinPriceSource()
    
    try:
        round_count = 1
        
        while True:
            print(f"Round {round_count}")
            print("-" * 20)
            
            # Get the current Bitcoin experience
            experience = orion.process_data_source(bitcoin)
            
            if "error" in experience:
                print(f"Error: {experience['error']}")
                continue
            
            # Show the results in a simple way
            price = experience['source_value']
            animation = experience['visual']['type']
            intensity = experience['visual']['intensity']
            
            print(f"Bitcoin Price: ${price:,.2f}")
            print(f"System Response Time: {experience['total_latency']:.3f} seconds")
            
            # Show the boxer animation
            print_boxer_animation(animation, intensity)
            
            # Show what else is happening
            if experience['audio']['volume'] > 0.1:
                print(f"🔊 Impact sound: {experience['audio']['volume']:.0%} volume")
            
            if experience['haptic']['intensity'] > 50:
                print(f"📳 Haptic feedback: {experience['haptic']['type']}")
            
            round_count += 1
            
            # Wait before next update
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n\n👋 Demo stopped by user")
        
        # Show final system stats
        status = orion.get_system_status()
        print(f"\nFinal Stats:")
        print(f"- Total punches thrown: {status['total_processed']}")
        print(f"- Average response time: {status['average_latency']:.3f}s")
        print(f"- System performance: {status['performance_rating']}")
        print(f"- Uptime: {status['uptime_seconds']:.0f} seconds")
        
        print("\n✨ Thanks for trying Orion Protocol!")

if __name__ == "__main__":
    main()

