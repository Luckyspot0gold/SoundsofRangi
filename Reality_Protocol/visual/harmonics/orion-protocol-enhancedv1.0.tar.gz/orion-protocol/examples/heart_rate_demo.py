#!/usr/bin/env python3
"""
Heart Rate Demo for Orion Protocol

This example shows how biometric data (heart rate) can be turned into
visual and haptic experiences. Great for fitness apps, health monitoring,
or stress management systems.

Run this file to see how your heartbeat becomes an experience!
"""

import sys
import os
import time

# Add the src directory to the path so we can import orion_core
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from orion_core import OrionProtocol, HeartRateSource

def print_heart_visualization(state, heart_rate, intensity):
    """
    Print ASCII art showing heart rate state
    
    Different visualizations for different heart rate zones
    """
    heart_art = {
        "calm": [
            "    💙",
            "  ♡   ♡",
            "    ~",
            "  Zen Mode"
        ],
        "active": [
            "    ❤️",
            "  ♡ ♡ ♡",
            "   ~~~",
            " Active Zone"
        ],
        "intense": [
            "    🔥❤️🔥",
            " ♡♡♡ ♡♡♡",
            "  ~~~~~",
            "Beast Mode!"
        ]
    }
    
    art = heart_art.get(state, heart_art["calm"])
    
    print(f"\nHeart Rate: {heart_rate:.0f} BPM - {state.upper()}")
    print(f"Intensity: {intensity:.0%}")
    for line in art:
        print(f"  {line}")
    print()

def get_heart_zone_info(heart_rate):
    """
    Provide educational information about heart rate zones
    """
    if heart_rate < 60:
        return "Resting Zone", "Perfect for recovery and relaxation"
    elif heart_rate < 90:
        return "Light Activity", "Great for warm-up and cool-down"
    elif heart_rate < 120:
        return "Moderate Zone", "Ideal for building endurance"
    elif heart_rate < 150:
        return "Vigorous Zone", "High-intensity training territory"
    else:
        return "Maximum Zone", "Peak performance - be careful!"

def simulate_workout():
    """
    Simulate a workout session with changing heart rate
    """
    print("🏃‍♂️ WORKOUT SIMULATION")
    print("=" * 30)
    
    orion = OrionProtocol()
    heart_source = HeartRateSource()
    
    # Simulate different workout phases
    phases = [
        ("Warm-up", 5, 70),
        ("Light Jog", 3, 95),
        ("Sprint!", 2, 140),
        ("Recovery", 3, 85),
        ("Cool Down", 2, 65)
    ]
    
    for phase_name, duration, target_rate in phases:
        print(f"\n🎯 {phase_name} Phase")
        print("-" * 20)
        
        # Gradually adjust heart rate to target
        heart_source.base_rate = target_rate
        
        for second in range(duration):
            experience = orion.process_data_source(heart_source)
            
            if "error" not in experience:
                hr = experience['source_value']
                state = experience['visual']['type']
                intensity = experience['visual']['intensity']
                
                # Show heart visualization
                print_heart_visualization(state, hr, intensity)
                
                # Educational info
                zone, description = get_heart_zone_info(hr)
                print(f"Zone: {zone}")
                print(f"Tip: {description}")
                
                # Show system responses
                haptic = experience['haptic']
                if haptic['intensity'] > 100:
                    print(f"📳 Cooling vest activated: {haptic['intensity']} intensity")
                
                if hr > 130:
                    print("⚠️  High intensity detected - stay hydrated!")
                
            time.sleep(1)
    
    print("\n🎉 Workout complete! Great job!")

def main():
    print("❤️ HEART RATE MONITOR - Orion Protocol Demo")
    print("=" * 50)
    print("Experience your heartbeat through sight, sound, and touch!")
    print("\nChoose your demo:")
    print("1. Real-time monitoring")
    print("2. Workout simulation")
    
    choice = input("\nEnter choice (1 or 2): ").strip()
    
    if choice == "2":
        simulate_workout()
        return
    
    # Real-time monitoring
    print("\n📊 REAL-TIME HEART RATE MONITORING")
    print("=" * 40)
    print("(Press Ctrl+C to stop)\n")
    
    orion = OrionProtocol()
    heart_source = HeartRateSource()
    
    try:
        measurement_count = 1
        
        while True:
            print(f"Measurement #{measurement_count}")
            print("-" * 25)
            
            # Get current heart rate experience
            experience = orion.process_data_source(heart_source)
            
            if "error" in experience:
                print(f"Error: {experience['error']}")
                continue
            
            # Extract the data
            hr = experience['source_value']
            state = experience['visual']['type']
            intensity = experience['visual']['intensity']
            
            # Show visualization
            print_heart_visualization(state, hr, intensity)
            
            # Educational information
            zone, description = get_heart_zone_info(hr)
            print(f"Heart Zone: {zone}")
            print(f"Health Tip: {description}")
            
            # System performance
            print(f"Response Time: {experience['total_latency']:.3f}s")
            print(f"Coherence: {experience['harmonic']['coherence']:.1%}")
            
            # Show multi-sensory outputs
            audio = experience['audio']
            haptic = experience['haptic']
            
            if audio['volume'] > 0.2:
                print(f"🎵 Heartbeat sound: {audio['volume']:.0%} volume")
            
            if haptic['intensity'] > 50:
                print(f"📳 Pulse feedback: {haptic['type']} pattern")
            
            measurement_count += 1
            time.sleep(3)  # Heart rate updates every 3 seconds
            
    except KeyboardInterrupt:
        print("\n\n👋 Monitoring stopped")
        
        # Show session summary
        status = orion.get_system_status()
        print(f"\nSession Summary:")
        print(f"- Total measurements: {status['total_processed']}")
        print(f"- Average response time: {status['average_latency']:.3f}s")
        print(f"- System performance: {status['performance_rating']}")
        print(f"- Session duration: {status['uptime_seconds']:.0f} seconds")
        
        print("\n💙 Stay healthy with Orion Protocol!")

if __name__ == "__main__":
    main()

