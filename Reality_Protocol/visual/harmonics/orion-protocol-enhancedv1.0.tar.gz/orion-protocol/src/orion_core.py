#!/usr/bin/env python3
"""
Orion Protocol Core System

A simple system that turns any measurement into experiences you can see, hear, and feel.
Like a universal translator for your senses.

Author: W.J. McCrea & Manus AI
Version: 1.0.0
License: MIT
"""

import numpy as np
import time
import json
import logging
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from abc import ABC, abstractmethod

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class OrionConfig:
    """Configuration for the Orion Protocol system"""
    base_frequency: float = 432.0  # Hz - The special frequency that makes everything sync
    max_latency: float = 0.05      # seconds - Must respond in less than 50ms
    buffer_size: int = 1024        # samples - How much data we keep in memory
    sample_rate: int = 44100       # Hz - Audio quality
    frame_rate: int = 60           # fps - Visual smoothness
    log_level: str = "INFO"        # How much detail to show in logs

class DataSource(ABC):
    """Base class for any source of numbers (Bitcoin, heart rate, temperature, etc.)"""
    
    @abstractmethod
    def get_current_value(self) -> float:
        """Get the current measurement value"""
        pass
    
    @abstractmethod
    def get_data_type(self) -> str:
        """What kind of measurement this is (price, temperature, etc.)"""
        pass

class BitcoinPriceSource(DataSource):
    """Gets Bitcoin price data - our first example"""
    
    def __init__(self):
        self.current_price = 50000.0  # Starting price in USD
        self.last_update = time.time()
    
    def get_current_value(self) -> float:
        """Simulate Bitcoin price changes"""
        # In real version, this would connect to Coinbase API
        # For now, we simulate realistic price movements
        time_passed = time.time() - self.last_update
        if time_passed > 1.0:  # Update every second
            # Random walk with slight upward bias
            change_percent = np.random.normal(0.001, 0.02)  # 0.1% average, 2% volatility
            self.current_price *= (1 + change_percent)
            self.last_update = time.time()
            logger.debug(f"Bitcoin price updated: ${self.current_price:.2f}")
        
        return self.current_price
    
    def get_data_type(self) -> str:
        return "cryptocurrency_price"

class HeartRateSource(DataSource):
    """Simulates heart rate data"""
    
    def __init__(self):
        self.base_rate = 75  # Normal resting heart rate
        self.current_rate = self.base_rate
    
    def get_current_value(self) -> float:
        """Simulate heart rate with natural variation"""
        # Heart rate varies naturally
        variation = np.random.normal(0, 2)  # Small random changes
        self.current_rate = max(50, min(150, self.base_rate + variation))
        return self.current_rate
    
    def get_data_type(self) -> str:
        return "biometric_heart_rate"

class HarmonicProcessor:
    """
    The brain of Orion Protocol
    
    Takes any kind of measurement and converts it to a 432Hz wave
    that carries all the information in a way that syncs perfectly
    with visual, audio, and physical outputs.
    """
    
    def __init__(self, config: OrionConfig):
        self.config = config
        self.buffer = np.zeros(config.buffer_size, dtype=np.complex128)
        self.buffer_index = 0
        logger.info(f"Harmonic processor initialized at {config.base_frequency}Hz")
    
    def normalize_data(self, value: float, data_type: str) -> float:
        """
        Convert any measurement to a standard scale (0-1)
        
        This is like translating different languages into one common language
        """
        normalization_rules = {
            "cryptocurrency_price": lambda x: min(1.0, x / 100000),  # $100k = max
            "biometric_heart_rate": lambda x: (x - 50) / 100,        # 50-150 bpm range
            "temperature_celsius": lambda x: (x + 50) / 100,         # -50 to +50°C range
            "percentage": lambda x: x / 100,                         # 0-100% range
            "default": lambda x: min(1.0, max(0.0, x))              # Clamp to 0-1
        }
        
        normalizer = normalization_rules.get(data_type, normalization_rules["default"])
        normalized = normalizer(value)
        
        logger.debug(f"Normalized {data_type} value {value} to {normalized}")
        return normalized
    
    def create_carrier_wave(self, duration: float = 0.1) -> np.ndarray:
        """
        Create the 432Hz carrier wave
        
        This is the special frequency that makes everything work together
        """
        t = np.linspace(0, duration, int(self.config.sample_rate * duration))
        carrier = np.sin(2 * np.pi * self.config.base_frequency * t)
        return carrier
    
    def modulate_signal(self, normalized_value: float, carrier: np.ndarray) -> np.ndarray:
        """
        Embed the measurement data into the 432Hz wave
        
        Like hiding a secret message in a song
        """
        # Amplitude modulation - the strength of the wave carries the information
        modulated = normalized_value * carrier
        
        # Add to circular buffer for processing
        buffer_end = (self.buffer_index + len(modulated)) % len(self.buffer)
        if buffer_end > self.buffer_index:
            self.buffer[self.buffer_index:buffer_end] = modulated[:buffer_end - self.buffer_index]
        else:
            # Handle wrap-around
            first_part = len(self.buffer) - self.buffer_index
            self.buffer[self.buffer_index:] = modulated[:first_part]
            self.buffer[:buffer_end] = modulated[first_part:first_part + buffer_end]
        
        self.buffer_index = buffer_end
        
        return modulated
    
    def process(self, data_source: DataSource) -> Dict[str, Any]:
        """
        Main processing function
        
        Takes a measurement and converts it to synchronized outputs
        """
        start_time = time.time()
        
        # Get the current measurement
        current_value = data_source.get_current_value()
        data_type = data_source.get_data_type()
        
        # Convert to standard scale
        normalized = self.normalize_data(current_value, data_type)
        
        # Create the 432Hz carrier wave
        carrier = self.create_carrier_wave()
        
        # Embed the data in the wave
        harmonic_signal = self.modulate_signal(normalized, carrier)
        
        # Calculate processing time
        processing_time = time.time() - start_time
        
        # Create the synchronized output package
        output = {
            "timestamp": time.time(),
            "original_value": current_value,
            "data_type": data_type,
            "normalized_value": normalized,
            "harmonic_signal": harmonic_signal.tolist(),  # Convert to JSON-serializable
            "processing_time": processing_time,
            "frequency": self.config.base_frequency,
            "buffer_coherence": self.calculate_coherence()
        }
        
        # Check if we're meeting our speed requirements
        if processing_time > self.config.max_latency:
            logger.warning(f"Processing took {processing_time:.3f}s, exceeds max latency of {self.config.max_latency:.3f}s")
        else:
            logger.debug(f"Processing completed in {processing_time:.3f}s")
        
        return output
    
    def calculate_coherence(self) -> float:
        """
        Measure how well synchronized our system is
        
        Returns a number from 0 to 1, where 1 means perfect sync
        """
        if len(self.buffer) == 0:
            return 0.0
        
        # Calculate the phase coherence of the buffer
        # This is a simplified version - real implementation would be more complex
        buffer_real = np.real(self.buffer)
        buffer_imag = np.imag(self.buffer)
        
        coherence = np.abs(np.mean(buffer_real + 1j * buffer_imag)) / np.mean(np.abs(self.buffer))
        return min(1.0, coherence)

class AnimationEngine:
    """
    Converts harmonic signals into visual animations
    
    This is what makes the Bitcoin boxer punch when the price goes up
    """
    
    def __init__(self):
        self.animation_history = []
        logger.info("Animation engine initialized")
    
    def select_animation(self, harmonic_data: Dict[str, Any]) -> str:
        """
        Choose which animation to show based on the data
        
        Simple rules that anyone can understand:
        - Small change = small animation
        - Big change = big animation
        """
        normalized_value = harmonic_data["normalized_value"]
        data_type = harmonic_data["data_type"]
        
        if data_type == "cryptocurrency_price":
            # Bitcoin price animations
            if normalized_value < 0.1:
                return "idle"
            elif normalized_value < 0.3:
                return "jab"
            elif normalized_value < 0.6:
                return "cross"
            elif normalized_value < 0.8:
                return "hook"
            else:
                return "uppercut"
        
        elif data_type == "biometric_heart_rate":
            # Heart rate animations
            if normalized_value < 0.3:
                return "calm"
            elif normalized_value < 0.7:
                return "active"
            else:
                return "intense"
        
        else:
            # Default animations for any other data type
            if normalized_value < 0.5:
                return "low_activity"
            else:
                return "high_activity"
    
    def generate_animation_data(self, animation_type: str, harmonic_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create the data needed to show the animation
        """
        animation_data = {
            "type": animation_type,
            "intensity": harmonic_data["normalized_value"],
            "duration": 1.0,  # seconds
            "timestamp": harmonic_data["timestamp"],
            "sync_frequency": harmonic_data["frequency"]
        }
        
        # Add animation-specific parameters
        if animation_type in ["jab", "cross", "hook", "uppercut"]:
            animation_data.update({
                "power_level": int(harmonic_data["normalized_value"] * 100),
                "impact_frame": 30,  # Frame where the punch connects
                "recovery_frames": 20
            })
        
        self.animation_history.append(animation_data)
        
        # Keep only recent animations to save memory
        if len(self.animation_history) > 100:
            self.animation_history = self.animation_history[-100:]
        
        logger.info(f"Generated {animation_type} animation with {animation_data['intensity']:.2f} intensity")
        
        return animation_data

class AudioEngine:
    """
    Converts harmonic signals into sounds
    
    This creates the impact sounds when the boxer punches
    """
    
    def __init__(self, config: OrionConfig):
        self.config = config
        logger.info("Audio engine initialized")
    
    def generate_audio(self, harmonic_data: Dict[str, Any], animation_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create audio that matches the animation perfectly
        """
        # Use the harmonic signal as the base for audio
        harmonic_signal = np.array(harmonic_data["harmonic_signal"])
        
        # Create different sounds based on animation type
        animation_type = animation_data["type"]
        intensity = animation_data["intensity"]
        
        if animation_type in ["jab", "cross", "hook", "uppercut"]:
            # Impact sounds for punches
            # Create a sharp attack with quick decay
            attack_samples = int(0.01 * self.config.sample_rate)  # 10ms attack
            decay_samples = int(0.2 * self.config.sample_rate)    # 200ms decay
            
            total_samples = attack_samples + decay_samples
            envelope = np.concatenate([
                np.linspace(0, intensity, attack_samples),
                np.linspace(intensity, 0, decay_samples)
            ])
            
            # Mix with harmonic signal
            if len(harmonic_signal) < total_samples:
                harmonic_signal = np.tile(harmonic_signal, 
                                        int(np.ceil(total_samples / len(harmonic_signal))))
            
            audio_signal = harmonic_signal[:total_samples] * envelope
            
        else:
            # Ambient sounds for other animations
            audio_signal = harmonic_signal * intensity * 0.5
        
        audio_data = {
            "signal": audio_signal.tolist(),
            "sample_rate": self.config.sample_rate,
            "duration": len(audio_signal) / self.config.sample_rate,
            "volume": intensity,
            "sync_timestamp": harmonic_data["timestamp"]
        }
        
        logger.debug(f"Generated audio for {animation_type} with {len(audio_signal)} samples")
        
        return audio_data

class HapticEngine:
    """
    Converts harmonic signals into vibrations and physical feedback
    
    This makes you feel the punch when the boxer hits
    """
    
    def __init__(self):
        self.haptic_devices = []
        logger.info("Haptic engine initialized")
    
    def generate_haptic_feedback(self, harmonic_data: Dict[str, Any], animation_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create vibration patterns that match the animation
        """
        animation_type = animation_data["type"]
        intensity = animation_data["intensity"]
        
        if animation_type in ["jab", "cross", "hook", "uppercut"]:
            # Sharp vibration for punches
            haptic_pattern = {
                "type": "impact",
                "intensity": int(intensity * 255),  # 0-255 range for haptic devices
                "duration": 100,  # milliseconds
                "pattern": [255, 0, 128, 0, 64, 0],  # Sharp hit with echoes
                "sync_timestamp": harmonic_data["timestamp"]
            }
        
        elif animation_type in ["calm", "active", "intense"]:
            # Gentle pulse for biometric data
            pulse_rate = 60 + (intensity * 60)  # 60-120 pulses per minute
            haptic_pattern = {
                "type": "pulse",
                "intensity": int(intensity * 128),  # Gentler for biometric
                "pulse_rate": pulse_rate,
                "duration": 1000,  # 1 second
                "sync_timestamp": harmonic_data["timestamp"]
            }
        
        else:
            # Default gentle feedback
            haptic_pattern = {
                "type": "ambient",
                "intensity": int(intensity * 64),
                "duration": 500,
                "sync_timestamp": harmonic_data["timestamp"]
            }
        
        logger.debug(f"Generated haptic feedback: {haptic_pattern['type']} at {haptic_pattern['intensity']} intensity")
        
        return haptic_pattern

class OrionProtocol:
    """
    The main Orion Protocol system
    
    This coordinates everything to create synchronized experiences
    from any kind of measurement data.
    """
    
    def __init__(self, config: Optional[OrionConfig] = None):
        self.config = config or OrionConfig()
        
        # Initialize all the engines
        self.harmonic_processor = HarmonicProcessor(self.config)
        self.animation_engine = AnimationEngine()
        self.audio_engine = AudioEngine(self.config)
        self.haptic_engine = HapticEngine()
        
        # Keep track of system performance
        self.stats = {
            "total_processed": 0,
            "average_latency": 0.0,
            "coherence_history": [],
            "start_time": time.time()
        }
        
        logger.info("Orion Protocol system initialized successfully")
    
    def process_data_source(self, data_source: DataSource) -> Dict[str, Any]:
        """
        Main function: Turn a measurement into a complete experience
        
        This is where the magic happens - one number becomes
        synchronized visual, audio, and haptic experiences.
        """
        start_time = time.time()
        
        try:
            # Step 1: Process the raw data into harmonic form
            harmonic_data = self.harmonic_processor.process(data_source)
            
            # Step 2: Generate synchronized outputs
            animation_data = self.animation_engine.generate_animation_data(
                self.animation_engine.select_animation(harmonic_data),
                harmonic_data
            )
            
            audio_data = self.audio_engine.generate_audio(harmonic_data, animation_data)
            
            haptic_data = self.haptic_engine.generate_haptic_feedback(harmonic_data, animation_data)
            
            # Step 3: Package everything together
            complete_experience = {
                "timestamp": harmonic_data["timestamp"],
                "source_value": harmonic_data["original_value"],
                "source_type": harmonic_data["data_type"],
                "harmonic": {
                    "frequency": harmonic_data["frequency"],
                    "coherence": harmonic_data["buffer_coherence"],
                    "processing_time": harmonic_data["processing_time"]
                },
                "visual": animation_data,
                "audio": audio_data,
                "haptic": haptic_data,
                "total_latency": time.time() - start_time
            }
            
            # Update system statistics
            self.update_stats(complete_experience)
            
            logger.info(f"Complete experience generated for {harmonic_data['data_type']} "
                       f"value {harmonic_data['original_value']:.2f} "
                       f"in {complete_experience['total_latency']:.3f}s")
            
            return complete_experience
            
        except Exception as e:
            logger.error(f"Error processing data source: {e}")
            return {"error": str(e), "timestamp": time.time()}
    
    def update_stats(self, experience: Dict[str, Any]) -> None:
        """Keep track of how well the system is performing"""
        self.stats["total_processed"] += 1
        
        # Update average latency
        current_latency = experience["total_latency"]
        total = self.stats["total_processed"]
        self.stats["average_latency"] = (
            (self.stats["average_latency"] * (total - 1) + current_latency) / total
        )
        
        # Track coherence
        coherence = experience["harmonic"]["coherence"]
        self.stats["coherence_history"].append(coherence)
        
        # Keep only recent coherence measurements
        if len(self.stats["coherence_history"]) > 1000:
            self.stats["coherence_history"] = self.stats["coherence_history"][-1000:]
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get information about how well the system is running"""
        uptime = time.time() - self.stats["start_time"]
        
        coherence_history = self.stats["coherence_history"]
        avg_coherence = np.mean(coherence_history) if coherence_history else 0.0
        
        return {
            "status": "running",
            "uptime_seconds": uptime,
            "total_processed": self.stats["total_processed"],
            "average_latency": self.stats["average_latency"],
            "average_coherence": avg_coherence,
            "target_latency": self.config.max_latency,
            "base_frequency": self.config.base_frequency,
            "performance_rating": self.calculate_performance_rating()
        }
    
    def calculate_performance_rating(self) -> str:
        """Simple performance rating"""
        if self.stats["average_latency"] > self.config.max_latency:
            return "needs_improvement"
        elif self.stats["average_latency"] > self.config.max_latency * 0.8:
            return "good"
        else:
            return "excellent"

# Example usage and testing functions
def demo_bitcoin_boxer():
    """Demonstrate the Bitcoin boxer concept"""
    print("🥊 Bitcoin Boxer Demo")
    print("=" * 50)
    
    # Create the system
    orion = OrionProtocol()
    bitcoin_source = BitcoinPriceSource()
    
    # Process several data points
    for i in range(5):
        experience = orion.process_data_source(bitcoin_source)
        
        if "error" not in experience:
            print(f"Bitcoin Price: ${experience['source_value']:.2f}")
            print(f"Animation: {experience['visual']['type']}")
            print(f"Power Level: {experience['visual']['intensity']:.2f}")
            print(f"Latency: {experience['total_latency']:.3f}s")
            print("-" * 30)
        
        time.sleep(1)
    
    # Show system status
    status = orion.get_system_status()
    print(f"\nSystem Status: {status['performance_rating']}")
    print(f"Average Latency: {status['average_latency']:.3f}s")
    print(f"Coherence: {status['average_coherence']:.3f}")

def demo_heart_rate_monitor():
    """Demonstrate biometric monitoring"""
    print("❤️ Heart Rate Monitor Demo")
    print("=" * 50)
    
    orion = OrionProtocol()
    heart_source = HeartRateSource()
    
    for i in range(5):
        experience = orion.process_data_source(heart_source)
        
        if "error" not in experience:
            print(f"Heart Rate: {experience['source_value']:.0f} BPM")
            print(f"State: {experience['visual']['type']}")
            print(f"Haptic: {experience['haptic']['type']}")
            print("-" * 30)
        
        time.sleep(1)

if __name__ == "__main__":
    print("🌟 Orion Protocol - Making the Invisible Visible")
    print("=" * 60)
    
    # Run demonstrations
    demo_bitcoin_boxer()
    print("\n")
    demo_heart_rate_monitor()
    
    print("\n✨ Demo complete! The future of data visualization is here.")

