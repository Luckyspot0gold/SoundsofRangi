#!/usr/bin/env python3
"""
AI Agents System for Orion Protocol

This module provides intelligent AI agents that can analyze market data,
provide commentary, generate insights, and interact with users in real-time.
The agents are powered by vLLM for high-performance inference and are
designed to enhance the multi-sensory experience with intelligent analysis.

Key Features:
- Market Analysis Agent: Provides technical analysis and insights
- Commentary Agent: Generates real-time market commentary
- Educational Agent: Explains market concepts and indicators
- Prediction Agent: Makes short-term market predictions
- Personality Agent: Adds character and engagement to interactions
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import aiohttp
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AgentType(Enum):
    """Types of AI agents available"""
    MARKET_ANALYST = "market_analyst"
    COMMENTATOR = "commentator"
    EDUCATOR = "educator"
    PREDICTOR = "predictor"
    PERSONALITY = "personality"
    RISK_MANAGER = "risk_manager"

class AgentPersonality(Enum):
    """Agent personality types"""
    PROFESSIONAL = "professional"      # Formal, analytical
    ENTHUSIASTIC = "enthusiastic"      # Excited, energetic
    CALM = "calm"                      # Zen, balanced
    AGGRESSIVE = "aggressive"          # Bold, confident
    CAUTIOUS = "cautious"             # Conservative, careful
    HUMOROUS = "humorous"             # Funny, entertaining

@dataclass
class AgentResponse:
    """Response from an AI agent"""
    agent_type: AgentType
    content: str
    confidence: float  # 0.0 to 1.0
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)
    suggested_actions: List[str] = field(default_factory=list)
    audio_cues: Dict[str, Any] = field(default_factory=dict)
    visual_effects: List[str] = field(default_factory=list)

@dataclass
class MarketContext:
    """Market context for AI agent analysis"""
    symbol: str
    current_price: float
    price_change: float
    volume: float
    indicators: Dict[str, float]
    recent_events: List[str]
    timeframe: str
    market_sentiment: str
    volatility: float
    trend_direction: str

class vLLMClient:
    """
    Client for communicating with vLLM OpenAI-compatible API
    
    This client handles all communication with the vLLM inference server
    and provides methods for generating text responses from AI models.
    """
    
    def __init__(self, base_url: str = "http://localhost:8000", 
                 model_name: str = "orion-agent", timeout: int = 30):
        self.base_url = base_url.rstrip('/')
        self.model_name = model_name
        self.timeout = timeout
        self.session = None
        
        # API endpoints
        self.chat_endpoint = f"{self.base_url}/v1/chat/completions"
        self.models_endpoint = f"{self.base_url}/v1/models"
        self.health_endpoint = f"{self.base_url}/health"
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.timeout))
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def health_check(self) -> bool:
        """Check if vLLM server is healthy"""
        try:
            async with self.session.get(self.health_endpoint) as response:
                return response.status == 200
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
    
    async def list_models(self) -> List[str]:
        """List available models"""
        try:
            async with self.session.get(self.models_endpoint) as response:
                if response.status == 200:
                    data = await response.json()
                    return [model['id'] for model in data.get('data', [])]
                else:
                    logger.error(f"Failed to list models: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error listing models: {e}")
            return []
    
    async def generate_response(self, messages: List[Dict[str, str]], 
                              max_tokens: int = 512, temperature: float = 0.7,
                              stream: bool = False) -> str:
        """
        Generate a response using the chat completions API
        
        Args:
            messages: List of message dictionaries with 'role' and 'content'
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0 to 1.0)
            stream: Whether to stream the response
            
        Returns:
            Generated response text
        """
        payload = {
            "model": self.model_name,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": stream
        }
        
        try:
            async with self.session.post(self.chat_endpoint, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    return data['choices'][0]['message']['content']
                else:
                    error_text = await response.text()
                    logger.error(f"API error {response.status}: {error_text}")
                    return "I'm having trouble processing that request right now."
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "I'm experiencing technical difficulties. Please try again."

class BaseAgent:
    """
    Base class for all AI agents
    
    Provides common functionality for agent initialization, prompt management,
    and response generation.
    """
    
    def __init__(self, agent_type: AgentType, personality: AgentPersonality = AgentPersonality.PROFESSIONAL,
                 vllm_client: vLLMClient = None):
        self.agent_type = agent_type
        self.personality = personality
        self.vllm_client = vllm_client
        
        # Agent configuration
        self.system_prompt = self._build_system_prompt()
        self.conversation_history = []
        self.max_history = 10
        
        # Performance tracking
        self.response_count = 0
        self.average_response_time = 0.0
        self.last_response_time = None
    
    def _build_system_prompt(self) -> str:
        """Build the system prompt for this agent"""
        base_prompt = f"""You are an AI agent for the Orion Protocol, a revolutionary system that converts market data into multi-sensory experiences using 432Hz harmonic processing.

Your role: {self.agent_type.value}
Your personality: {self.personality.value}

Key principles:
- All market data is processed through 432Hz harmonic frequencies
- Visual outputs include boxing animations, racing simulations, and character interactions
- Audio outputs use therapeutic frequencies and binaural beats
- Vibration patterns provide haptic feedback synchronized with market movements
- Educational content should be accessible to all skill levels

Always provide responses that are:
- Accurate and based on real market analysis
- Engaging and appropriate to your personality
- Helpful for understanding market conditions
- Supportive of the multi-sensory experience

Remember: You're part of a system that makes complex financial data intuitive through embodied cognition."""

        # Add personality-specific instructions
        personality_prompts = {
            AgentPersonality.PROFESSIONAL: "Maintain a formal, analytical tone. Focus on facts and data.",
            AgentPersonality.ENTHUSIASTIC: "Be energetic and excited about market movements. Use exclamation points!",
            AgentPersonality.CALM: "Speak in a zen-like, balanced manner. Emphasize harmony and balance.",
            AgentPersonality.AGGRESSIVE: "Be bold and confident. Make strong statements about market direction.",
            AgentPersonality.CAUTIOUS: "Always emphasize risk management and careful analysis.",
            AgentPersonality.HUMOROUS: "Add appropriate humor and wit to your responses."
        }
        
        base_prompt += f"\n\nPersonality guidance: {personality_prompts.get(self.personality, '')}"
        
        return base_prompt
    
    async def generate_response(self, context: MarketContext, user_input: str = None) -> AgentResponse:
        """
        Generate a response based on market context and optional user input
        
        Args:
            context: Current market context
            user_input: Optional user input or question
            
        Returns:
            Agent response with content and metadata
        """
        start_time = time.time()
        
        # Build the conversation messages
        messages = [{"role": "system", "content": self.system_prompt}]
        
        # Add conversation history
        for msg in self.conversation_history[-self.max_history:]:
            messages.append(msg)
        
        # Add current market context
        context_message = self._format_market_context(context)
        messages.append({"role": "user", "content": context_message})
        
        # Add user input if provided
        if user_input:
            messages.append({"role": "user", "content": f"User question: {user_input}"})
        
        # Generate response
        if self.vllm_client:
            content = await self.vllm_client.generate_response(messages)
        else:
            # Fallback to simulated response
            content = self._generate_fallback_response(context, user_input)
        
        # Calculate response time
        response_time = time.time() - start_time
        self._update_performance_metrics(response_time)
        
        # Update conversation history
        self.conversation_history.append({"role": "assistant", "content": content})
        if len(self.conversation_history) > self.max_history * 2:
            self.conversation_history = self.conversation_history[-self.max_history:]
        
        # Generate additional response metadata
        confidence = self._calculate_confidence(context, content)
        suggested_actions = self._generate_suggested_actions(context, content)
        audio_cues = self._generate_audio_cues(context, content)
        visual_effects = self._generate_visual_effects(context, content)
        
        return AgentResponse(
            agent_type=self.agent_type,
            content=content,
            confidence=confidence,
            timestamp=datetime.now(),
            metadata={
                'response_time': response_time,
                'market_symbol': context.symbol,
                'market_sentiment': context.market_sentiment,
                'personality': self.personality.value
            },
            suggested_actions=suggested_actions,
            audio_cues=audio_cues,
            visual_effects=visual_effects
        )
    
    def _format_market_context(self, context: MarketContext) -> str:
        """Format market context for the AI model"""
        return f"""Current Market Context:
Symbol: {context.symbol}
Price: ${context.current_price:,.2f} (Change: {context.price_change:+.2f}%)
Volume: {context.volume:,.0f}
Trend: {context.trend_direction}
Sentiment: {context.market_sentiment}
Volatility: {context.volatility:.2f}%
Timeframe: {context.timeframe}

Technical Indicators:
{json.dumps(context.indicators, indent=2)}

Recent Events:
{chr(10).join(f'- {event}' for event in context.recent_events)}

Please provide analysis and commentary appropriate to your role as a {self.agent_type.value}."""
    
    def _generate_fallback_response(self, context: MarketContext, user_input: str = None) -> str:
        """Generate a fallback response when vLLM is not available"""
        responses = {
            AgentType.MARKET_ANALYST: f"Based on current analysis of {context.symbol}, the {context.trend_direction} trend shows {context.market_sentiment} sentiment with {context.volatility:.1f}% volatility.",
            AgentType.COMMENTATOR: f"We're seeing {context.trend_direction} movement in {context.symbol} with a {context.price_change:+.2f}% change. The market is showing {context.market_sentiment} sentiment.",
            AgentType.EDUCATOR: f"Let me explain what's happening with {context.symbol}. The current {context.trend_direction} trend indicates market participants are feeling {context.market_sentiment}.",
            AgentType.PREDICTOR: f"Given the current {context.market_sentiment} sentiment and {context.volatility:.1f}% volatility, {context.symbol} may continue its {context.trend_direction} trajectory.",
            AgentType.PERSONALITY: f"Hey there! {context.symbol} is having quite a {context.trend_direction} day with {context.price_change:+.2f}% movement!",
            AgentType.RISK_MANAGER: f"Risk assessment for {context.symbol}: Current volatility at {context.volatility:.1f}% suggests {context.market_sentiment} conditions. Proceed with caution."
        }
        
        base_response = responses.get(self.agent_type, "Market analysis in progress...")
        
        if user_input:
            base_response += f" Regarding your question about '{user_input}', I'll need more specific market data to provide a detailed answer."
        
        return base_response
    
    def _calculate_confidence(self, context: MarketContext, content: str) -> float:
        """Calculate confidence score for the response"""
        # Base confidence on market data quality and response length
        base_confidence = 0.7
        
        # Adjust based on data availability
        if context.indicators:
            base_confidence += 0.1
        if context.recent_events:
            base_confidence += 0.1
        if len(content) > 50:
            base_confidence += 0.1
        
        return min(base_confidence, 1.0)
    
    def _generate_suggested_actions(self, context: MarketContext, content: str) -> List[str]:
        """Generate suggested actions based on the response"""
        actions = []
        
        if context.volatility > 5.0:
            actions.append("monitor_volatility")
        if abs(context.price_change) > 5.0:
            actions.append("check_news")
        if context.market_sentiment == "bullish":
            actions.append("consider_long_position")
        elif context.market_sentiment == "bearish":
            actions.append("consider_short_position")
        
        return actions
    
    def _generate_audio_cues(self, context: MarketContext, content: str) -> Dict[str, Any]:
        """Generate audio cues for the response"""
        base_frequency = 432.0
        
        # Adjust frequency based on market sentiment
        if context.market_sentiment == "bullish":
            frequency = base_frequency * 1.1
        elif context.market_sentiment == "bearish":
            frequency = base_frequency * 0.9
        else:
            frequency = base_frequency
        
        return {
            'frequency': frequency,
            'duration': min(len(content) / 100, 3.0),
            'amplitude': 0.3 + min(context.volatility / 10, 0.4)
        }
    
    def _generate_visual_effects(self, context: MarketContext, content: str) -> List[str]:
        """Generate visual effects for the response"""
        effects = []
        
        if context.volatility > 5.0:
            effects.append("screen_shake")
        if abs(context.price_change) > 3.0:
            effects.append("price_flash")
        if "bullish" in content.lower():
            effects.append("green_glow")
        elif "bearish" in content.lower():
            effects.append("red_glow")
        
        return effects
    
    def _update_performance_metrics(self, response_time: float):
        """Update performance tracking metrics"""
        self.response_count += 1
        self.last_response_time = response_time
        
        # Update rolling average
        if self.response_count == 1:
            self.average_response_time = response_time
        else:
            alpha = 0.1  # Smoothing factor
            self.average_response_time = (alpha * response_time + 
                                        (1 - alpha) * self.average_response_time)

class MarketAnalystAgent(BaseAgent):
    """
    Specialized agent for technical market analysis
    
    Provides detailed technical analysis, indicator interpretation,
    and market structure analysis.
    """
    
    def __init__(self, personality: AgentPersonality = AgentPersonality.PROFESSIONAL,
                 vllm_client: vLLMClient = None):
        super().__init__(AgentType.MARKET_ANALYST, personality, vllm_client)
        
        # Specialized knowledge areas
        self.specializations = [
            "technical_analysis",
            "chart_patterns",
            "indicator_analysis",
            "market_structure",
            "volume_analysis"
        ]
    
    def _build_system_prompt(self) -> str:
        base_prompt = super()._build_system_prompt()
        
        analyst_prompt = """

As a Market Analyst, you specialize in:
- Technical indicator analysis (RSI, MACD, Bollinger Bands, etc.)
- Chart pattern recognition
- Support and resistance levels
- Volume analysis and market structure
- Risk assessment and probability analysis

Always provide:
- Specific technical levels and targets
- Probability assessments for market moves
- Risk/reward ratios
- Multiple timeframe analysis when relevant
- Clear reasoning for your analysis

Format your responses with clear sections for different aspects of analysis."""
        
        return base_prompt + analyst_prompt

class CommentatorAgent(BaseAgent):
    """
    Specialized agent for real-time market commentary
    
    Provides engaging, real-time commentary on market movements
    with appropriate emotional context.
    """
    
    def __init__(self, personality: AgentPersonality = AgentPersonality.ENTHUSIASTIC,
                 vllm_client: vLLMClient = None):
        super().__init__(AgentType.COMMENTATOR, personality, vllm_client)
        
        # Commentary styles
        self.commentary_styles = [
            "play_by_play",
            "color_commentary",
            "breaking_news",
            "market_recap"
        ]
    
    def _build_system_prompt(self) -> str:
        base_prompt = super()._build_system_prompt()
        
        commentator_prompt = """

As a Market Commentator, you provide:
- Real-time play-by-play of market action
- Emotional context for price movements
- Analogies to sports or other familiar activities
- Excitement and energy appropriate to market volatility
- Quick, digestible insights for active traders

Your commentary should be:
- Immediate and reactive to current price action
- Engaging and entertaining
- Informative but not overly technical
- Appropriate to the current market energy level

Think of yourself as a sports commentator for financial markets."""
        
        return base_prompt + commentator_prompt

class EducatorAgent(BaseAgent):
    """
    Specialized agent for market education
    
    Explains market concepts, indicators, and trading principles
    in accessible language.
    """
    
    def __init__(self, personality: AgentPersonality = AgentPersonality.CALM,
                 vllm_client: vLLMClient = None):
        super().__init__(AgentType.EDUCATOR, personality, vllm_client)
        
        # Educational topics
        self.topics = [
            "technical_indicators",
            "market_psychology",
            "risk_management",
            "trading_basics",
            "harmonic_analysis"
        ]
    
    def _build_system_prompt(self) -> str:
        base_prompt = super()._build_system_prompt()
        
        educator_prompt = """

As an Educator, your mission is to:
- Explain complex market concepts in simple terms
- Use analogies and examples from everyday life
- Break down technical indicators into understandable components
- Teach the 'why' behind market movements
- Help users understand the Orion Protocol's unique approach

Your explanations should be:
- Clear and jargon-free
- Progressive (building from simple to complex)
- Practical with real-world applications
- Encouraging and supportive
- Connected to the multi-sensory experience

Always ask yourself: "Would a beginner understand this?"
"""
        
        return base_prompt + educator_prompt

class AIAgentOrchestrator:
    """
    Orchestrates multiple AI agents and manages their interactions
    
    This class coordinates different agents, manages their responses,
    and provides a unified interface for the Orion Protocol system.
    """
    
    def __init__(self, vllm_base_url: str = "http://localhost:8000"):
        self.vllm_client = None
        self.vllm_base_url = vllm_base_url
        
        # Initialize agents
        self.agents = {}
        self._initialize_agents()
        
        # Response caching
        self.response_cache = {}
        self.cache_duration = 30  # seconds
        
        # Performance monitoring
        self.total_requests = 0
        self.successful_requests = 0
        self.average_response_time = 0.0
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.vllm_client = vLLMClient(self.vllm_base_url)
        await self.vllm_client.__aenter__()
        
        # Update agents with vLLM client
        for agent in self.agents.values():
            agent.vllm_client = self.vllm_client
        
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.vllm_client:
            await self.vllm_client.__aexit__(exc_type, exc_val, exc_tb)
    
    def _initialize_agents(self):
        """Initialize all AI agents"""
        self.agents = {
            AgentType.MARKET_ANALYST: MarketAnalystAgent(AgentPersonality.PROFESSIONAL),
            AgentType.COMMENTATOR: CommentatorAgent(AgentPersonality.ENTHUSIASTIC),
            AgentType.EDUCATOR: EducatorAgent(AgentPersonality.CALM),
            AgentType.PREDICTOR: BaseAgent(AgentType.PREDICTOR, AgentPersonality.CAUTIOUS),
            AgentType.PERSONALITY: BaseAgent(AgentType.PERSONALITY, AgentPersonality.HUMOROUS),
            AgentType.RISK_MANAGER: BaseAgent(AgentType.RISK_MANAGER, AgentPersonality.CAUTIOUS)
        }
    
    async def get_agent_response(self, agent_type: AgentType, context: MarketContext,
                               user_input: str = None) -> AgentResponse:
        """
        Get a response from a specific agent
        
        Args:
            agent_type: Type of agent to query
            context: Market context for analysis
            user_input: Optional user input
            
        Returns:
            Agent response
        """
        self.total_requests += 1
        start_time = time.time()
        
        try:
            # Check cache first
            cache_key = f"{agent_type.value}_{context.symbol}_{hash(str(context.indicators))}"
            if cache_key in self.response_cache:
                cached_response, timestamp = self.response_cache[cache_key]
                if time.time() - timestamp < self.cache_duration:
                    return cached_response
            
            # Get agent
            agent = self.agents.get(agent_type)
            if not agent:
                raise ValueError(f"Agent type {agent_type} not found")
            
            # Generate response
            response = await agent.generate_response(context, user_input)
            
            # Cache response
            self.response_cache[cache_key] = (response, time.time())
            
            # Update performance metrics
            response_time = time.time() - start_time
            self.successful_requests += 1
            self._update_performance_metrics(response_time)
            
            return response
            
        except Exception as e:
            logger.error(f"Error getting agent response: {e}")
            
            # Return fallback response
            return AgentResponse(
                agent_type=agent_type,
                content=f"I'm experiencing technical difficulties. Please try again in a moment.",
                confidence=0.1,
                timestamp=datetime.now(),
                metadata={'error': str(e)}
            )
    
    async def get_multi_agent_analysis(self, context: MarketContext,
                                     agent_types: List[AgentType] = None) -> Dict[AgentType, AgentResponse]:
        """
        Get analysis from multiple agents simultaneously
        
        Args:
            context: Market context for analysis
            agent_types: List of agent types to query (default: all)
            
        Returns:
            Dictionary mapping agent types to their responses
        """
        if agent_types is None:
            agent_types = list(self.agents.keys())
        
        # Create tasks for concurrent execution
        tasks = []
        for agent_type in agent_types:
            task = self.get_agent_response(agent_type, context)
            tasks.append((agent_type, task))
        
        # Execute all tasks concurrently
        results = {}
        for agent_type, task in tasks:
            try:
                response = await task
                results[agent_type] = response
            except Exception as e:
                logger.error(f"Error getting response from {agent_type}: {e}")
                results[agent_type] = AgentResponse(
                    agent_type=agent_type,
                    content="Analysis unavailable",
                    confidence=0.0,
                    timestamp=datetime.now(),
                    metadata={'error': str(e)}
                )
        
        return results
    
    async def health_check(self) -> Dict[str, Any]:
        """Check the health of the AI agent system"""
        health_status = {
            'vllm_available': False,
            'agents_initialized': len(self.agents),
            'cache_size': len(self.response_cache),
            'total_requests': self.total_requests,
            'success_rate': self.successful_requests / max(self.total_requests, 1),
            'average_response_time': self.average_response_time
        }
        
        if self.vllm_client:
            health_status['vllm_available'] = await self.vllm_client.health_check()
        
        return health_status
    
    def _update_performance_metrics(self, response_time: float):
        """Update performance tracking metrics"""
        if self.total_requests == 1:
            self.average_response_time = response_time
        else:
            alpha = 0.1  # Smoothing factor
            self.average_response_time = (alpha * response_time + 
                                        (1 - alpha) * self.average_response_time)
    
    def clear_cache(self):
        """Clear the response cache"""
        self.response_cache.clear()
    
    def get_agent_stats(self) -> Dict[str, Any]:
        """Get statistics for all agents"""
        stats = {}
        for agent_type, agent in self.agents.items():
            stats[agent_type.value] = {
                'response_count': agent.response_count,
                'average_response_time': agent.average_response_time,
                'last_response_time': agent.last_response_time,
                'personality': agent.personality.value
            }
        return stats

# Example usage and testing
if __name__ == "__main__":
    async def test_ai_agents():
        print("🤖 AI Agents System Test")
        print("=" * 40)
        
        # Create market context
        context = MarketContext(
            symbol="BTC-USD",
            current_price=45000.0,
            price_change=2.5,
            volume=1500000,
            indicators={
                "RSI": 65.0,
                "MACD": 0.15,
                "BB_position": 75.0
            },
            recent_events=["Whale buy detected", "Volume spike"],
            timeframe="1h",
            market_sentiment="bullish",
            volatility=3.2,
            trend_direction="up"
        )
        
        # Test with orchestrator
        async with AIAgentOrchestrator() as orchestrator:
            # Health check
            health = await orchestrator.health_check()
            print(f"System Health: {health}")
            
            # Test individual agent
            print("\nTesting Market Analyst...")
            analyst_response = await orchestrator.get_agent_response(
                AgentType.MARKET_ANALYST, context
            )
            print(f"Analyst: {analyst_response.content}")
            print(f"Confidence: {analyst_response.confidence:.2f}")
            
            # Test commentator
            print("\nTesting Commentator...")
            commentator_response = await orchestrator.get_agent_response(
                AgentType.COMMENTATOR, context
            )
            print(f"Commentator: {commentator_response.content}")
            
            # Test multi-agent analysis
            print("\nTesting Multi-Agent Analysis...")
            multi_response = await orchestrator.get_multi_agent_analysis(
                context, [AgentType.MARKET_ANALYST, AgentType.EDUCATOR]
            )
            
            for agent_type, response in multi_response.items():
                print(f"\n{agent_type.value}: {response.content[:100]}...")
            
            # Show statistics
            stats = orchestrator.get_agent_stats()
            print(f"\nAgent Statistics:")
            for agent_name, agent_stats in stats.items():
                print(f"  {agent_name}: {agent_stats['response_count']} responses")
    
    # Run the test
    asyncio.run(test_ai_agents())

