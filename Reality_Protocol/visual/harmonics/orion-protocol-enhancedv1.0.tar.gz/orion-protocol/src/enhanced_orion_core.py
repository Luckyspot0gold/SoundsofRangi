#!/usr/bin/env python3
"""
Enhanced Orion Protocol Core System

This is the next-generation Orion Protocol that integrates all advanced features:
- AI Agents for intelligent market analysis and commentary
- Advanced Audio Engine with 432Hz frequency generation
- Market Sensory System with sophisticated indicator mapping
- Real-time vibration patterns and haptic feedback
- Multi-realm output coordination with enhanced synchronization

This enhanced core maintains backward compatibility while adding revolutionary
new capabilities for market visualization and multi-sensory experiences.
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Optional, Any, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import threading
import queue

# Import our enhanced modules
from audio_engine import AudioEngine, AudioParameters, AudioMode, VibrationEngine
from market_sensory_system import (
    MarketSensorySystem, IndicatorType, 
    AnimationType, VibrationPattern, SensoryOutput
)
from ai_agents import (
    AIAgentOrchestrator, AgentType, AgentResponse, 
    MarketAnalystAgent, CommentatorAgent, EducatorAgent
)

# Import original core for compatibility
from orion_core import OrionProtocol as BaseOrionProtocol

# Define MarketContext locally since it's not in market_sensory_system
@dataclass
class MarketContext:
    """Market context for AI agent analysis"""
    symbol: str
    current_price: float
    price_change: float
    volume: float
    indicators: Dict[str, float]
    recent_events: List[str]
    timeframe: str
    market_sentiment: str
    volatility: float
    trend_direction: str

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class EnhancedMarketEvent:
    """Enhanced market event with AI analysis and sensory output"""
    symbol: str
    timestamp: datetime
    price_data: Dict[str, float]
    volume_data: Dict[str, float]
    technical_indicators: Dict[str, float]
    market_context: MarketContext
    sensory_outputs: Dict[str, SensoryOutput]
    ai_analysis: Dict[AgentType, AgentResponse] = field(default_factory=dict)
    audio_layers: List[int] = field(default_factory=list)
    vibration_patterns: List[Dict] = field(default_factory=list)
    visual_effects: List[str] = field(default_factory=list)

@dataclass
class SystemConfiguration:
    """Configuration for the enhanced Orion Protocol system"""
    # Audio settings
    base_frequency: float = 432.0
    sample_rate: int = 44100
    audio_buffer_size: int = 1024
    master_volume: float = 0.7
    
    # AI settings
    vllm_base_url: str = "http://localhost:8000"
    ai_enabled: bool = True
    ai_cache_duration: int = 30
    
    # Market data settings
    update_interval: float = 1.0  # seconds
    max_history_length: int = 1000
    indicator_periods: Dict[str, int] = field(default_factory=lambda: {
        'RSI': 14,
        'MACD_fast': 12,
        'MACD_slow': 26,
        'MACD_signal': 9,
        'BB_period': 20,
        'Stochastic': 14
    })
    
    # Performance settings
    max_concurrent_tasks: int = 10
    response_timeout: float = 5.0
    enable_caching: bool = True
    
    # Output settings
    enable_audio: bool = True
    enable_vibration: bool = True
    enable_ai_commentary: bool = True
    auto_adjust_volume: bool = True

class EnhancedOrionProtocol:
    """
    Enhanced Orion Protocol with AI agents, advanced audio, and sensory mapping
    
    This class represents the next evolution of the Orion Protocol, integrating
    all advanced features while maintaining the core 432Hz harmonic processing
    and multi-realm output capabilities.
    """
    
    def __init__(self, config: SystemConfiguration = None):
        self.config = config or SystemConfiguration()
        
        # Initialize core components
        self.base_orion = BaseOrionProtocol()
        self.audio_engine = AudioEngine(
            sample_rate=self.config.sample_rate,
            buffer_size=self.config.audio_buffer_size
        )
        self.market_sensory = MarketSensorySystem(
            base_frequency=self.config.base_frequency
        )
        self.ai_orchestrator = None  # Initialized in start()
        
        # System state
        self.is_running = False
        self.start_time = None
        self.total_events_processed = 0
        self.active_symbols = set()
        
        # Data storage
        self.market_history = {}
        self.event_queue = queue.Queue()
        self.active_events = {}
        
        # Performance monitoring
        self.performance_metrics = {
            'events_per_second': 0.0,
            'average_processing_time': 0.0,
            'ai_response_time': 0.0,
            'audio_latency': 0.0,
            'total_uptime': 0.0
        }
        
        # Threading
        self.executor = ThreadPoolExecutor(max_workers=self.config.max_concurrent_tasks)
        self.processing_thread = None
        self.monitoring_thread = None
        
        # Event callbacks
        self.event_callbacks = {
            'market_update': [],
            'ai_analysis': [],
            'audio_generated': [],
            'system_alert': []
        }
    
    async def start(self):
        """Start the enhanced Orion Protocol system"""
        if self.is_running:
            logger.warning("System is already running")
            return
        
        logger.info("🚀 Starting Enhanced Orion Protocol System")
        
        try:
            # Initialize AI orchestrator
            if self.config.ai_enabled:
                self.ai_orchestrator = AIAgentOrchestrator(self.config.vllm_base_url)
                await self.ai_orchestrator.__aenter__()
                
                # Test AI system
                health = await self.ai_orchestrator.health_check()
                logger.info(f"AI System Health: {health}")
            
            # Start audio engine
            if self.config.enable_audio:
                self.audio_engine.set_master_volume(self.config.master_volume)
                self.audio_engine.start_engine()
                logger.info("🎵 Audio engine started")
            
            # Start processing threads
            self.is_running = True
            self.start_time = datetime.now()
            
            self.processing_thread = threading.Thread(target=self._processing_loop)
            self.processing_thread.daemon = True
            self.processing_thread.start()
            
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop)
            self.monitoring_thread.daemon = True
            self.monitoring_thread.start()
            
            logger.info("✅ Enhanced Orion Protocol System started successfully")
            
        except Exception as e:
            logger.error(f"Failed to start system: {e}")
            await self.stop()
            raise
    
    async def stop(self):
        """Stop the enhanced Orion Protocol system"""
        if not self.is_running:
            return
        
        logger.info("🛑 Stopping Enhanced Orion Protocol System")
        
        self.is_running = False
        
        # Stop audio engine
        if self.audio_engine:
            self.audio_engine.stop_engine()
        
        # Stop AI orchestrator
        if self.ai_orchestrator:
            await self.ai_orchestrator.__aexit__(None, None, None)
        
        # Wait for threads to finish
        if self.processing_thread:
            self.processing_thread.join(timeout=2.0)
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=2.0)
        
        # Shutdown executor
        self.executor.shutdown(wait=True)
        
        logger.info("✅ Enhanced Orion Protocol System stopped")
    
    async def process_market_data(self, symbol: str, price_data: Dict[str, Any],
                                volume_data: Dict[str, Any] = None) -> EnhancedMarketEvent:
        """
        Process market data through the enhanced system
        
        Args:
            symbol: Trading symbol (e.g., 'BTC-USD')
            price_data: Dictionary containing price information
            volume_data: Optional volume information
            
        Returns:
            Enhanced market event with all analysis and outputs
        """
        start_time = time.time()
        
        try:
            # Prepare data
            if volume_data is None:
                volume_data = {'volume': price_data.get('volume', 1000000)}
            
            # Update market history
            if symbol not in self.market_history:
                self.market_history[symbol] = {
                    'prices': [],
                    'volumes': [],
                    'highs': [],
                    'lows': [],
                    'timestamps': []
                }
            
            history = self.market_history[symbol]
            history['prices'].append(price_data['price'])
            history['volumes'].append(volume_data['volume'])
            history['highs'].append(price_data.get('high', price_data['price']))
            history['lows'].append(price_data.get('low', price_data['price']))
            history['timestamps'].append(datetime.now())
            
            # Limit history length
            max_len = self.config.max_history_length
            for key in history:
                if len(history[key]) > max_len:
                    history[key] = history[key][-max_len:]
            
            # Calculate technical indicators
            technical_indicators = {}
            if len(history['prices']) >= 2:
                # Use market sensory system to calculate indicators
                sensory_outputs = self.market_sensory.process_market_data(
                    symbol, history['prices'], history['volumes'],
                    history['highs'], history['lows']
                )
                
                # Extract indicator values from sensory outputs
                for indicator_name, output in sensory_outputs.items():
                    if 'value' in output.metadata:
                        technical_indicators[indicator_name] = output.metadata['value']
            
            # Create market context
            price_change = 0.0
            if len(history['prices']) >= 2:
                price_change = ((history['prices'][-1] - history['prices'][-2]) / 
                              history['prices'][-2] * 100)
            
            market_context = MarketContext(
                symbol=symbol,
                current_price=price_data['price'],
                price_change=price_change,
                volume=volume_data['volume'],
                indicators=technical_indicators,
                recent_events=[],  # Could be populated from news feeds
                timeframe='1m',
                market_sentiment=self._determine_sentiment(technical_indicators),
                volatility=self._calculate_volatility(history['prices'][-20:]),
                trend_direction=self._determine_trend(history['prices'][-5:])
            )
            
            # Generate sensory outputs
            sensory_outputs = {}
            if len(history['prices']) >= 10:  # Need enough data for indicators
                sensory_outputs = self.market_sensory.process_market_data(
                    symbol, history['prices'], history['volumes'],
                    history['highs'], history['lows']
                )
            
            # Create enhanced market event
            event = EnhancedMarketEvent(
                symbol=symbol,
                timestamp=datetime.now(),
                price_data=price_data,
                volume_data=volume_data,
                technical_indicators=technical_indicators,
                market_context=market_context,
                sensory_outputs=sensory_outputs
            )
            
            # Process through AI agents (async)
            if self.config.ai_enabled and self.ai_orchestrator:
                try:
                    ai_analysis = await asyncio.wait_for(
                        self.ai_orchestrator.get_multi_agent_analysis(market_context),
                        timeout=self.config.response_timeout
                    )
                    event.ai_analysis = ai_analysis
                except asyncio.TimeoutError:
                    logger.warning(f"AI analysis timeout for {symbol}")
                except Exception as e:
                    logger.error(f"AI analysis error: {e}")
            
            # Generate audio outputs
            if self.config.enable_audio and sensory_outputs:
                audio_layers = []
                for indicator_name, output in sensory_outputs.items():
                    try:
                        layer_id = self.audio_engine.play_tone(
                            frequency=output.audio_frequency,
                            duration=output.audio_duration,
                            amplitude=output.audio_amplitude * self.config.master_volume
                        )
                        audio_layers.append(layer_id)
                    except Exception as e:
                        logger.error(f"Audio generation error: {e}")
                
                event.audio_layers = audio_layers
            
            # Generate vibration patterns
            if self.config.enable_vibration and sensory_outputs:
                vibration_patterns = []
                for indicator_name, output in sensory_outputs.items():
                    pattern_data = {
                        'pattern': output.vibration_pattern.value,
                        'intensity': output.vibration_intensity,
                        'duration': output.vibration_duration,
                        'indicator': indicator_name
                    }
                    vibration_patterns.append(pattern_data)
                
                event.vibration_patterns = vibration_patterns
            
            # Collect visual effects
            visual_effects = []
            for output in sensory_outputs.values():
                visual_effects.extend(output.effects)
            event.visual_effects = list(set(visual_effects))  # Remove duplicates
            
            # Update performance metrics
            processing_time = time.time() - start_time
            self._update_performance_metrics(processing_time)
            
            # Track active symbols
            self.active_symbols.add(symbol)
            self.total_events_processed += 1
            
            # Store active event
            self.active_events[symbol] = event
            
            # Trigger callbacks
            await self._trigger_callbacks('market_update', event)
            
            return event
            
        except Exception as e:
            logger.error(f"Error processing market data for {symbol}: {e}")
            raise
    
    async def get_ai_commentary(self, symbol: str, agent_type: AgentType = AgentType.COMMENTATOR,
                              user_question: str = None) -> Optional[AgentResponse]:
        """
        Get AI commentary for a specific symbol
        
        Args:
            symbol: Trading symbol
            agent_type: Type of AI agent to query
            user_question: Optional user question
            
        Returns:
            AI agent response or None if not available
        """
        if not self.config.ai_enabled or not self.ai_orchestrator:
            return None
        
        if symbol not in self.active_events:
            logger.warning(f"No active event for symbol {symbol}")
            return None
        
        try:
            event = self.active_events[symbol]
            response = await self.ai_orchestrator.get_agent_response(
                agent_type, event.market_context, user_question
            )
            
            # Trigger callback
            await self._trigger_callbacks('ai_analysis', {
                'symbol': symbol,
                'agent_type': agent_type,
                'response': response
            })
            
            return response
            
        except Exception as e:
            logger.error(f"Error getting AI commentary: {e}")
            return None
    
    def create_market_audio(self, symbol: str, intensity: float = 1.0) -> Dict[str, Any]:
        """
        Create audio based on current market conditions
        
        Args:
            symbol: Trading symbol
            intensity: Audio intensity multiplier
            
        Returns:
            Audio creation result
        """
        if not self.config.enable_audio or symbol not in self.active_events:
            return {}
        
        try:
            event = self.active_events[symbol]
            
            # Use the most significant indicator for audio
            if event.sensory_outputs:
                # Find the output with highest significance
                best_output = max(
                    event.sensory_outputs.values(),
                    key=lambda x: x.metadata.get('significance', 0)
                )
                
                # Create audio based on this output
                audio_result = self.audio_engine.create_market_audio(
                    best_output.metadata.get('value', 50),
                    best_output.metadata.get('indicator', 'PRICE'),
                    intensity
                )
                
                # Trigger callback
                asyncio.create_task(self._trigger_callbacks('audio_generated', {
                    'symbol': symbol,
                    'audio_result': audio_result
                }))
                
                return audio_result
            
        except Exception as e:
            logger.error(f"Error creating market audio: {e}")
        
        return {}
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        uptime = (datetime.now() - self.start_time).total_seconds() if self.start_time else 0
        
        status = {
            'system': {
                'is_running': self.is_running,
                'uptime_seconds': uptime,
                'start_time': self.start_time.isoformat() if self.start_time else None,
                'total_events_processed': self.total_events_processed,
                'active_symbols': list(self.active_symbols),
                'configuration': {
                    'base_frequency': self.config.base_frequency,
                    'ai_enabled': self.config.ai_enabled,
                    'audio_enabled': self.config.enable_audio,
                    'vibration_enabled': self.config.enable_vibration
                }
            },
            'performance': self.performance_metrics.copy(),
            'components': {
                'audio_engine': self.audio_engine.get_system_status() if self.audio_engine else {},
                'market_sensory': self.market_sensory.get_system_status() if self.market_sensory else {},
                'ai_orchestrator': None  # Will be populated async
            },
            'active_events': {
                symbol: {
                    'timestamp': event.timestamp.isoformat(),
                    'price': event.price_data.get('price', 0),
                    'indicators_count': len(event.technical_indicators),
                    'ai_analysis_count': len(event.ai_analysis),
                    'audio_layers': len(event.audio_layers),
                    'vibration_patterns': len(event.vibration_patterns),
                    'visual_effects': len(event.visual_effects)
                }
                for symbol, event in self.active_events.items()
            }
        }
        
        return status
    
    async def get_detailed_status(self) -> Dict[str, Any]:
        """Get detailed system status including AI health"""
        status = self.get_system_status()
        
        # Add AI orchestrator status
        if self.ai_orchestrator:
            try:
                ai_health = await self.ai_orchestrator.health_check()
                ai_stats = self.ai_orchestrator.get_agent_stats()
                status['components']['ai_orchestrator'] = {
                    'health': ai_health,
                    'agent_stats': ai_stats
                }
            except Exception as e:
                status['components']['ai_orchestrator'] = {'error': str(e)}
        
        return status
    
    def register_callback(self, event_type: str, callback: Callable):
        """Register a callback for system events"""
        if event_type in self.event_callbacks:
            self.event_callbacks[event_type].append(callback)
        else:
            logger.warning(f"Unknown event type: {event_type}")
    
    def unregister_callback(self, event_type: str, callback: Callable):
        """Unregister a callback"""
        if event_type in self.event_callbacks and callback in self.event_callbacks[event_type]:
            self.event_callbacks[event_type].remove(callback)
    
    # Private methods
    
    def _processing_loop(self):
        """Main processing loop for background tasks"""
        while self.is_running:
            try:
                # Process any queued events
                try:
                    event = self.event_queue.get(timeout=0.1)
                    # Process event here if needed
                    self.event_queue.task_done()
                except queue.Empty:
                    pass
                
                # Cleanup old events
                self._cleanup_old_events()
                
                # Update performance metrics
                self._update_system_metrics()
                
                time.sleep(0.1)  # Small delay to prevent busy waiting
                
            except Exception as e:
                logger.error(f"Error in processing loop: {e}")
                time.sleep(1.0)  # Longer delay on error
    
    def _monitoring_loop(self):
        """Monitoring loop for system health"""
        while self.is_running:
            try:
                # Monitor system resources
                # Monitor audio engine health
                # Monitor AI system health
                # Log performance metrics
                
                time.sleep(5.0)  # Monitor every 5 seconds
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(10.0)
    
    def _cleanup_old_events(self):
        """Clean up old events to prevent memory leaks"""
        cutoff_time = datetime.now() - timedelta(minutes=5)
        
        symbols_to_remove = []
        for symbol, event in self.active_events.items():
            if event.timestamp < cutoff_time:
                symbols_to_remove.append(symbol)
        
        for symbol in symbols_to_remove:
            del self.active_events[symbol]
            if symbol in self.active_symbols:
                self.active_symbols.remove(symbol)
    
    def _update_performance_metrics(self, processing_time: float):
        """Update performance tracking metrics"""
        # Update average processing time
        if self.total_events_processed == 1:
            self.performance_metrics['average_processing_time'] = processing_time
        else:
            alpha = 0.1  # Smoothing factor
            current_avg = self.performance_metrics['average_processing_time']
            self.performance_metrics['average_processing_time'] = (
                alpha * processing_time + (1 - alpha) * current_avg
            )
        
        # Update events per second
        if self.start_time:
            uptime = (datetime.now() - self.start_time).total_seconds()
            if uptime > 0:
                self.performance_metrics['events_per_second'] = self.total_events_processed / uptime
    
    def _update_system_metrics(self):
        """Update system-wide metrics"""
        if self.start_time:
            self.performance_metrics['total_uptime'] = (
                datetime.now() - self.start_time
            ).total_seconds()
    
    async def _trigger_callbacks(self, event_type: str, data: Any):
        """Trigger registered callbacks for an event type"""
        if event_type in self.event_callbacks:
            for callback in self.event_callbacks[event_type]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(data)
                    else:
                        callback(data)
                except Exception as e:
                    logger.error(f"Error in callback for {event_type}: {e}")
    
    def _determine_sentiment(self, indicators: Dict[str, float]) -> str:
        """Determine market sentiment from indicators"""
        if not indicators:
            return 'neutral'
        
        bullish_signals = 0
        bearish_signals = 0
        
        # RSI analysis
        if 'RSI' in indicators:
            rsi = indicators['RSI']
            if rsi > 60:
                bullish_signals += 1
            elif rsi < 40:
                bearish_signals += 1
        
        # MACD analysis
        if 'MACD' in indicators:
            macd = indicators['MACD']
            if macd > 0:
                bullish_signals += 1
            else:
                bearish_signals += 1
        
        # Determine overall sentiment
        if bullish_signals > bearish_signals:
            return 'bullish'
        elif bearish_signals > bullish_signals:
            return 'bearish'
        else:
            return 'neutral'
    
    def _calculate_volatility(self, prices: List[float]) -> float:
        """Calculate volatility from price series"""
        if len(prices) < 2:
            return 0.0
        
        import numpy as np
        returns = np.diff(prices) / prices[:-1]
        return float(np.std(returns) * 100)
    
    def _determine_trend(self, prices: List[float]) -> str:
        """Determine trend direction from recent prices"""
        if len(prices) < 2:
            return 'sideways'
        
        if prices[-1] > prices[0] * 1.01:  # 1% threshold
            return 'up'
        elif prices[-1] < prices[0] * 0.99:
            return 'down'
        else:
            return 'sideways'

# Example usage and testing
async def test_enhanced_orion():
    """Test the enhanced Orion Protocol system"""
    print("🚀 Enhanced Orion Protocol Test")
    print("=" * 50)
    
    # Create configuration
    config = SystemConfiguration(
        base_frequency=432.0,
        ai_enabled=True,  # Will fallback gracefully if vLLM not available
        enable_audio=True,
        enable_vibration=True,
        master_volume=0.5
    )
    
    # Create enhanced system
    orion = EnhancedOrionProtocol(config)
    
    try:
        # Start the system
        await orion.start()
        
        # Simulate market data
        print("\n📊 Processing market data...")
        
        # Bitcoin data
        btc_event = await orion.process_market_data(
            'BTC-USD',
            {
                'price': 45000.0,
                'high': 45500.0,
                'low': 44500.0,
                'volume': 1500000
            }
        )
        
        print(f"BTC Event processed:")
        print(f"  - Technical indicators: {len(btc_event.technical_indicators)}")
        print(f"  - Sensory outputs: {len(btc_event.sensory_outputs)}")
        print(f"  - AI analysis: {len(btc_event.ai_analysis)}")
        print(f"  - Audio layers: {len(btc_event.audio_layers)}")
        print(f"  - Visual effects: {btc_event.visual_effects}")
        
        # Test AI commentary
        if orion.config.ai_enabled:
            print("\n🤖 Getting AI commentary...")
            commentary = await orion.get_ai_commentary('BTC-USD', AgentType.COMMENTATOR)
            if commentary:
                print(f"Commentary: {commentary.content[:100]}...")
                print(f"Confidence: {commentary.confidence:.2f}")
        
        # Test market audio
        print("\n🎵 Creating market audio...")
        audio_result = orion.create_market_audio('BTC-USD', intensity=0.8)
        if audio_result:
            print(f"Audio created: {audio_result.get('frequency', 'N/A')} Hz")
        
        # Show system status
        print("\n📈 System Status:")
        status = await orion.get_detailed_status()
        print(f"  - Uptime: {status['system']['uptime_seconds']:.1f} seconds")
        print(f"  - Events processed: {status['system']['total_events_processed']}")
        print(f"  - Active symbols: {status['system']['active_symbols']}")
        print(f"  - Performance: {status['performance']['average_processing_time']:.3f}s avg")
        
        # Wait a moment to see the system in action
        await asyncio.sleep(2.0)
        
        print("\n✅ Enhanced Orion Protocol test completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Stop the system
        await orion.stop()

if __name__ == "__main__":
    # Run the test
    asyncio.run(test_enhanced_orion())

