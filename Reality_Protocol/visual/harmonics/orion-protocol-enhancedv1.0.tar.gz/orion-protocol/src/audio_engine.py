#!/usr/bin/env python3
"""
Advanced Audio Engine for Orion Protocol

This module provides sophisticated audio generation capabilities including:
- 432Hz base frequency generation and harmonics
- Dynamic tone and pitch control
- Real-time audio synthesis
- Multi-layered audio composition
- Binaural beats and therapeutic frequencies

The audio engine is designed to work seamlessly with the Orion Protocol's
harmonic processing system while providing rich, immersive audio experiences.
"""

import numpy as np
import threading
import time
import queue
import json
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass
from enum import Enum

try:
    import sounddevice as sd
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False
    print("Warning: sounddevice not available. Audio will be simulated.")

class AudioMode(Enum):
    """Audio generation modes for different applications"""
    HARMONIC = "harmonic"          # Pure 432Hz harmonics
    THERAPEUTIC = "therapeutic"    # Healing frequencies
    MUSICAL = "musical"           # Musical scales and chords
    AMBIENT = "ambient"           # Environmental sounds
    IMPACT = "impact"             # Sharp, percussive sounds
    BINAURAL = "binaural"         # Binaural beats for focus

@dataclass
class AudioParameters:
    """Parameters for audio generation"""
    frequency: float = 432.0       # Base frequency in Hz
    amplitude: float = 0.5         # Volume level (0.0 to 1.0)
    duration: float = 1.0          # Duration in seconds
    fade_in: float = 0.1           # Fade in time in seconds
    fade_out: float = 0.1          # Fade out time in seconds
    harmonics: List[float] = None  # Harmonic multipliers
    modulation: Optional[Dict] = None  # Frequency/amplitude modulation
    stereo_pan: float = 0.0        # Stereo positioning (-1.0 to 1.0)

class FrequencyGenerator:
    """
    Generates audio frequencies based on 432Hz tuning system
    
    The 432Hz tuning is mathematically consistent with the universe's
    natural frequencies and creates more harmonious audio experiences.
    """
    
    def __init__(self, sample_rate: int = 44100):
        self.sample_rate = sample_rate
        self.base_frequency = 432.0
        
        # Musical intervals based on 432Hz tuning
        self.musical_ratios = {
            'unison': 1.0,
            'minor_second': 16/15,
            'major_second': 9/8,
            'minor_third': 6/5,
            'major_third': 5/4,
            'perfect_fourth': 4/3,
            'tritone': 45/32,
            'perfect_fifth': 3/2,
            'minor_sixth': 8/5,
            'major_sixth': 5/3,
            'minor_seventh': 16/9,
            'major_seventh': 15/8,
            'octave': 2.0
        }
        
        # Therapeutic frequencies (Hz)
        self.therapeutic_frequencies = {
            'grounding': 256,      # Root chakra
            'creativity': 288,     # Sacral chakra  
            'confidence': 320,     # Solar plexus chakra
            'love': 341.3,         # Heart chakra
            'expression': 384,     # Throat chakra
            'intuition': 426.7,    # Third eye chakra
            'connection': 480,     # Crown chakra
            'healing': 528,        # DNA repair frequency
            'transformation': 741, # Consciousness expansion
            'awakening': 852,      # Spiritual awakening
            'unity': 963          # Divine connection
        }
    
    def generate_tone(self, params: AudioParameters) -> np.ndarray:
        """
        Generate a pure tone with the specified parameters
        
        Args:
            params: Audio generation parameters
            
        Returns:
            numpy array containing the generated audio samples
        """
        duration_samples = int(params.duration * self.sample_rate)
        t = np.linspace(0, params.duration, duration_samples, False)
        
        # Generate base frequency
        wave = np.sin(2 * np.pi * params.frequency * t)
        
        # Add harmonics if specified
        if params.harmonics:
            for harmonic_ratio in params.harmonics:
                harmonic_freq = params.frequency * harmonic_ratio
                harmonic_wave = np.sin(2 * np.pi * harmonic_freq * t)
                # Harmonics get progressively quieter
                harmonic_amplitude = 1.0 / harmonic_ratio
                wave += harmonic_wave * harmonic_amplitude
        
        # Apply modulation if specified
        if params.modulation:
            wave = self._apply_modulation(wave, t, params.modulation)
        
        # Apply amplitude
        wave *= params.amplitude
        
        # Apply fade in/out
        wave = self._apply_fades(wave, params.fade_in, params.fade_out)
        
        # Normalize to prevent clipping
        if np.max(np.abs(wave)) > 0:
            wave = wave / np.max(np.abs(wave)) * params.amplitude
        
        return wave
    
    def generate_chord(self, root_freq: float, intervals: List[str], 
                      params: AudioParameters) -> np.ndarray:
        """
        Generate a musical chord based on 432Hz tuning
        
        Args:
            root_freq: Root frequency of the chord
            intervals: List of musical intervals to include
            params: Audio generation parameters
            
        Returns:
            numpy array containing the chord audio
        """
        duration_samples = int(params.duration * self.sample_rate)
        chord_wave = np.zeros(duration_samples)
        
        # Generate each note in the chord
        for interval in intervals:
            if interval in self.musical_ratios:
                note_freq = root_freq * self.musical_ratios[interval]
                note_params = AudioParameters(
                    frequency=note_freq,
                    amplitude=params.amplitude / len(intervals),
                    duration=params.duration,
                    fade_in=params.fade_in,
                    fade_out=params.fade_out
                )
                note_wave = self.generate_tone(note_params)
                chord_wave += note_wave
        
        return chord_wave
    
    def generate_binaural_beat(self, base_freq: float, beat_freq: float,
                              params: AudioParameters) -> np.ndarray:
        """
        Generate binaural beats for brainwave entrainment
        
        Args:
            base_freq: Base frequency for both ears
            beat_freq: Difference frequency for the beat
            params: Audio generation parameters
            
        Returns:
            Stereo audio array with binaural beat
        """
        duration_samples = int(params.duration * self.sample_rate)
        t = np.linspace(0, params.duration, duration_samples, False)
        
        # Left ear: base frequency
        left_wave = np.sin(2 * np.pi * base_freq * t)
        
        # Right ear: base frequency + beat frequency
        right_wave = np.sin(2 * np.pi * (base_freq + beat_freq) * t)
        
        # Apply amplitude and fades
        left_wave *= params.amplitude
        right_wave *= params.amplitude
        
        left_wave = self._apply_fades(left_wave, params.fade_in, params.fade_out)
        right_wave = self._apply_fades(right_wave, params.fade_in, params.fade_out)
        
        # Combine into stereo array
        stereo_wave = np.column_stack((left_wave, right_wave))
        
        return stereo_wave
    
    def _apply_modulation(self, wave: np.ndarray, t: np.ndarray, 
                         modulation: Dict) -> np.ndarray:
        """Apply frequency or amplitude modulation to the wave"""
        if 'frequency' in modulation:
            mod_freq = modulation['frequency']
            mod_depth = modulation.get('depth', 0.1)
            freq_mod = 1 + mod_depth * np.sin(2 * np.pi * mod_freq * t)
            # This is a simplified FM - real FM is more complex
            wave = wave * freq_mod
        
        if 'amplitude' in modulation:
            mod_freq = modulation['amplitude']
            mod_depth = modulation.get('depth', 0.1)
            amp_mod = 1 + mod_depth * np.sin(2 * np.pi * mod_freq * t)
            wave = wave * amp_mod
        
        return wave
    
    def _apply_fades(self, wave: np.ndarray, fade_in: float, 
                    fade_out: float) -> np.ndarray:
        """Apply fade in and fade out to prevent audio clicks"""
        fade_in_samples = int(fade_in * self.sample_rate)
        fade_out_samples = int(fade_out * self.sample_rate)
        
        # Fade in
        if fade_in_samples > 0:
            fade_in_curve = np.linspace(0, 1, fade_in_samples)
            wave[:fade_in_samples] *= fade_in_curve
        
        # Fade out
        if fade_out_samples > 0:
            fade_out_curve = np.linspace(1, 0, fade_out_samples)
            wave[-fade_out_samples:] *= fade_out_curve
        
        return wave

class VibrationEngine:
    """
    Generates vibration patterns for haptic feedback devices
    
    Vibration patterns are synchronized with audio and visual elements
    to create cohesive multi-sensory experiences.
    """
    
    def __init__(self):
        self.patterns = {
            'pulse': self._generate_pulse_pattern,
            'wave': self._generate_wave_pattern,
            'burst': self._generate_burst_pattern,
            'rhythm': self._generate_rhythm_pattern,
            'heartbeat': self._generate_heartbeat_pattern,
            'breathing': self._generate_breathing_pattern
        }
    
    def generate_pattern(self, pattern_type: str, intensity: float, 
                        duration: float, **kwargs) -> List[Tuple[float, float]]:
        """
        Generate a vibration pattern
        
        Args:
            pattern_type: Type of vibration pattern
            intensity: Vibration intensity (0.0 to 1.0)
            duration: Total duration in seconds
            **kwargs: Additional pattern-specific parameters
            
        Returns:
            List of (time, intensity) tuples defining the pattern
        """
        if pattern_type in self.patterns:
            return self.patterns[pattern_type](intensity, duration, **kwargs)
        else:
            # Default to simple pulse
            return self._generate_pulse_pattern(intensity, duration)
    
    def _generate_pulse_pattern(self, intensity: float, duration: float,
                               frequency: float = 2.0) -> List[Tuple[float, float]]:
        """Generate a simple pulsing pattern"""
        pattern = []
        pulse_duration = 1.0 / frequency
        half_pulse = pulse_duration / 2
        
        time = 0.0
        while time < duration:
            # On phase
            pattern.append((time, intensity))
            pattern.append((time + half_pulse, intensity))
            
            # Off phase
            pattern.append((time + half_pulse, 0.0))
            pattern.append((time + pulse_duration, 0.0))
            
            time += pulse_duration
        
        return pattern
    
    def _generate_wave_pattern(self, intensity: float, duration: float,
                              frequency: float = 1.0) -> List[Tuple[float, float]]:
        """Generate a smooth wave pattern"""
        pattern = []
        samples = int(duration * 20)  # 20 samples per second
        
        for i in range(samples):
            time = i / 20.0
            wave_intensity = intensity * (np.sin(2 * np.pi * frequency * time) + 1) / 2
            pattern.append((time, wave_intensity))
        
        return pattern
    
    def _generate_burst_pattern(self, intensity: float, duration: float,
                               burst_count: int = 3) -> List[Tuple[float, float]]:
        """Generate a burst pattern with multiple quick pulses"""
        pattern = []
        burst_duration = duration / burst_count
        pulse_duration = burst_duration * 0.1  # 10% of burst duration
        
        for burst in range(burst_count):
            burst_start = burst * burst_duration
            
            # Quick pulse
            pattern.append((burst_start, intensity))
            pattern.append((burst_start + pulse_duration, intensity))
            pattern.append((burst_start + pulse_duration, 0.0))
            pattern.append((burst_start + burst_duration, 0.0))
        
        return pattern
    
    def _generate_rhythm_pattern(self, intensity: float, duration: float,
                                rhythm: List[float] = None) -> List[Tuple[float, float]]:
        """Generate a rhythmic pattern based on timing array"""
        if rhythm is None:
            rhythm = [0.2, 0.2, 0.4, 0.2]  # Default rhythm
        
        pattern = []
        time = 0.0
        rhythm_duration = sum(rhythm)
        
        while time < duration:
            for beat_duration in rhythm:
                if time >= duration:
                    break
                
                # Beat on
                pattern.append((time, intensity))
                pattern.append((time + beat_duration * 0.5, intensity))
                
                # Beat off
                pattern.append((time + beat_duration * 0.5, 0.0))
                pattern.append((time + beat_duration, 0.0))
                
                time += beat_duration
        
        return pattern
    
    def _generate_heartbeat_pattern(self, intensity: float, duration: float,
                                   bpm: float = 72.0) -> List[Tuple[float, float]]:
        """Generate a heartbeat-like pattern"""
        pattern = []
        beat_interval = 60.0 / bpm
        
        time = 0.0
        while time < duration:
            # First beat (lub)
            pattern.append((time, intensity))
            pattern.append((time + 0.1, intensity))
            pattern.append((time + 0.1, 0.0))
            
            # Short pause
            pattern.append((time + 0.2, 0.0))
            
            # Second beat (dub)
            pattern.append((time + 0.2, intensity * 0.7))
            pattern.append((time + 0.3, intensity * 0.7))
            pattern.append((time + 0.3, 0.0))
            
            # Rest until next heartbeat
            pattern.append((time + beat_interval, 0.0))
            
            time += beat_interval
        
        return pattern
    
    def _generate_breathing_pattern(self, intensity: float, duration: float,
                                   breaths_per_minute: float = 12.0) -> List[Tuple[float, float]]:
        """Generate a breathing-like pattern"""
        pattern = []
        breath_duration = 60.0 / breaths_per_minute
        inhale_duration = breath_duration * 0.4
        exhale_duration = breath_duration * 0.6
        
        time = 0.0
        while time < duration:
            # Inhale (gradual increase)
            inhale_steps = 10
            for step in range(inhale_steps):
                step_time = time + (step / inhale_steps) * inhale_duration
                step_intensity = intensity * (step / inhale_steps)
                pattern.append((step_time, step_intensity))
            
            # Exhale (gradual decrease)
            exhale_steps = 15
            for step in range(exhale_steps):
                step_time = time + inhale_duration + (step / exhale_steps) * exhale_duration
                step_intensity = intensity * (1 - step / exhale_steps)
                pattern.append((step_time, step_intensity))
            
            time += breath_duration
        
        return pattern

class AudioEngine:
    """
    Main audio engine that coordinates all audio generation and playback
    
    This engine provides a high-level interface for generating complex
    audio experiences that integrate with the Orion Protocol system.
    """
    
    def __init__(self, sample_rate: int = 44100, buffer_size: int = 1024):
        self.sample_rate = sample_rate
        self.buffer_size = buffer_size
        self.frequency_generator = FrequencyGenerator(sample_rate)
        self.vibration_engine = VibrationEngine()
        
        # Audio playback state
        self.is_playing = False
        self.audio_queue = queue.Queue()
        self.playback_thread = None
        
        # Current audio layers
        self.active_layers = {}
        self.layer_counter = 0
        
        # Audio effects and processing
        self.master_volume = 0.7
        self.effects_enabled = True
        
        # Initialize audio device if available
        if AUDIO_AVAILABLE:
            try:
                sd.default.samplerate = sample_rate
                sd.default.channels = 2  # Stereo
                sd.default.dtype = np.float32
            except Exception as e:
                print(f"Warning: Could not initialize audio device: {e}")
                # Note: AUDIO_AVAILABLE is already global, just update it
                globals()['AUDIO_AVAILABLE'] = False
    
    def start_engine(self):
        """Start the audio engine and playback thread"""
        if not self.is_playing:
            self.is_playing = True
            self.playback_thread = threading.Thread(target=self._playback_loop)
            self.playback_thread.daemon = True
            self.playback_thread.start()
    
    def stop_engine(self):
        """Stop the audio engine and playback thread"""
        self.is_playing = False
        if self.playback_thread:
            self.playback_thread.join(timeout=1.0)
    
    def play_tone(self, frequency: float, duration: float = 1.0, 
                  amplitude: float = 0.5, mode: AudioMode = AudioMode.HARMONIC) -> int:
        """
        Play a single tone
        
        Args:
            frequency: Frequency in Hz
            duration: Duration in seconds
            amplitude: Volume level (0.0 to 1.0)
            mode: Audio generation mode
            
        Returns:
            Layer ID for controlling the audio
        """
        params = AudioParameters(
            frequency=frequency,
            amplitude=amplitude,
            duration=duration
        )
        
        if mode == AudioMode.HARMONIC:
            # Add harmonic series based on 432Hz
            params.harmonics = [2.0, 3.0, 4.0, 5.0]
        elif mode == AudioMode.THERAPEUTIC:
            # Use pure tone for therapeutic applications
            params.harmonics = None
        
        audio_data = self.frequency_generator.generate_tone(params)
        return self._add_audio_layer(audio_data)
    
    def play_chord(self, root_frequency: float, chord_type: str = 'major',
                   duration: float = 2.0, amplitude: float = 0.4) -> int:
        """
        Play a musical chord
        
        Args:
            root_frequency: Root frequency of the chord
            chord_type: Type of chord (major, minor, etc.)
            duration: Duration in seconds
            amplitude: Volume level
            
        Returns:
            Layer ID for controlling the audio
        """
        chord_intervals = {
            'major': ['unison', 'major_third', 'perfect_fifth'],
            'minor': ['unison', 'minor_third', 'perfect_fifth'],
            'seventh': ['unison', 'major_third', 'perfect_fifth', 'minor_seventh'],
            'sus4': ['unison', 'perfect_fourth', 'perfect_fifth']
        }
        
        intervals = chord_intervals.get(chord_type, chord_intervals['major'])
        
        params = AudioParameters(
            frequency=root_frequency,
            amplitude=amplitude,
            duration=duration,
            fade_in=0.2,
            fade_out=0.5
        )
        
        audio_data = self.frequency_generator.generate_chord(
            root_frequency, intervals, params
        )
        return self._add_audio_layer(audio_data)
    
    def play_binaural_beat(self, base_frequency: float = 432.0, 
                          beat_frequency: float = 10.0, duration: float = 60.0,
                          amplitude: float = 0.3) -> int:
        """
        Play binaural beats for brainwave entrainment
        
        Args:
            base_frequency: Base frequency for both ears
            beat_frequency: Beat frequency (difference between ears)
            duration: Duration in seconds
            amplitude: Volume level
            
        Returns:
            Layer ID for controlling the audio
        """
        params = AudioParameters(
            frequency=base_frequency,
            amplitude=amplitude,
            duration=duration,
            fade_in=2.0,
            fade_out=2.0
        )
        
        audio_data = self.frequency_generator.generate_binaural_beat(
            base_frequency, beat_frequency, params
        )
        return self._add_audio_layer(audio_data)
    
    def create_market_audio(self, market_value: float, indicator_type: str,
                           intensity: float = 1.0) -> Dict:
        """
        Create audio based on market data
        
        Args:
            market_value: Current market value or indicator reading
            indicator_type: Type of market indicator (RSI, MACD, etc.)
            intensity: Audio intensity multiplier
            
        Returns:
            Dictionary containing audio and vibration data
        """
        # Map market indicators to audio characteristics
        audio_mappings = {
            'RSI': {
                'frequency_base': 432.0,
                'frequency_range': 100.0,  # ±100 Hz
                'chord_type': 'major' if market_value > 50 else 'minor'
            },
            'MACD': {
                'frequency_base': 432.0,
                'frequency_range': 200.0,
                'chord_type': 'major' if market_value > 0 else 'minor'
            },
            'PRICE': {
                'frequency_base': 432.0,
                'frequency_range': 300.0,
                'chord_type': 'major'
            }
        }
        
        mapping = audio_mappings.get(indicator_type, audio_mappings['PRICE'])
        
        # Calculate frequency based on market value
        if indicator_type == 'RSI':
            # RSI ranges from 0-100
            frequency_offset = (market_value - 50) / 50 * mapping['frequency_range']
        elif indicator_type == 'MACD':
            # MACD can be positive or negative
            frequency_offset = np.clip(market_value, -1, 1) * mapping['frequency_range']
        else:
            # Generic percentage change
            frequency_offset = np.clip(market_value, -1, 1) * mapping['frequency_range']
        
        target_frequency = mapping['frequency_base'] + frequency_offset
        
        # Generate audio
        audio_layer = self.play_chord(
            root_frequency=target_frequency,
            chord_type=mapping['chord_type'],
            duration=1.0,
            amplitude=0.3 * intensity
        )
        
        # Generate vibration pattern
        vibration_intensity = min(abs(market_value) / 100.0, 1.0) * intensity
        vibration_pattern = self.vibration_engine.generate_pattern(
            'pulse', vibration_intensity, 1.0, frequency=2.0
        )
        
        return {
            'audio_layer': audio_layer,
            'frequency': target_frequency,
            'vibration_pattern': vibration_pattern,
            'intensity': intensity
        }
    
    def create_biometric_audio(self, heart_rate: float, stress_level: float = 0.5,
                              activity_level: float = 0.5) -> Dict:
        """
        Create audio based on biometric data
        
        Args:
            heart_rate: Heart rate in BPM
            stress_level: Stress level (0.0 to 1.0)
            activity_level: Activity level (0.0 to 1.0)
            
        Returns:
            Dictionary containing audio and vibration data
        """
        # Map heart rate to frequency (60-180 BPM -> 400-500 Hz)
        hr_frequency = 400 + (heart_rate - 60) / 120 * 100
        hr_frequency = np.clip(hr_frequency, 400, 500)
        
        # Create heartbeat rhythm
        vibration_pattern = self.vibration_engine.generate_pattern(
            'heartbeat', 0.3 + stress_level * 0.4, 5.0, bpm=heart_rate
        )
        
        # Create calming or energizing audio based on stress
        if stress_level > 0.7:
            # High stress - calming frequencies
            audio_layer = self.play_binaural_beat(
                base_frequency=432.0,
                beat_frequency=8.0,  # Alpha waves for relaxation
                duration=10.0,
                amplitude=0.2
            )
        elif activity_level > 0.7:
            # High activity - energizing frequencies
            audio_layer = self.play_binaural_beat(
                base_frequency=432.0,
                beat_frequency=15.0,  # Beta waves for focus
                duration=5.0,
                amplitude=0.3
            )
        else:
            # Normal state - balanced frequencies
            audio_layer = self.play_tone(
                frequency=hr_frequency,
                duration=2.0,
                amplitude=0.25,
                mode=AudioMode.THERAPEUTIC
            )
        
        return {
            'audio_layer': audio_layer,
            'heart_frequency': hr_frequency,
            'vibration_pattern': vibration_pattern,
            'stress_level': stress_level
        }
    
    def stop_layer(self, layer_id: int):
        """Stop a specific audio layer"""
        if layer_id in self.active_layers:
            del self.active_layers[layer_id]
    
    def stop_all_layers(self):
        """Stop all active audio layers"""
        self.active_layers.clear()
    
    def set_master_volume(self, volume: float):
        """Set the master volume (0.0 to 1.0)"""
        self.master_volume = np.clip(volume, 0.0, 1.0)
    
    def _add_audio_layer(self, audio_data: np.ndarray) -> int:
        """Add an audio layer and return its ID"""
        layer_id = self.layer_counter
        self.layer_counter += 1
        
        # Convert mono to stereo if needed
        if len(audio_data.shape) == 1:
            audio_data = np.column_stack((audio_data, audio_data))
        
        self.active_layers[layer_id] = {
            'data': audio_data,
            'position': 0,
            'start_time': time.time()
        }
        
        return layer_id
    
    def _playback_loop(self):
        """Main audio playback loop"""
        if not AUDIO_AVAILABLE:
            # Simulate audio playback
            while self.is_playing:
                time.sleep(0.1)
            return
        
        try:
            with sd.OutputStream(
                samplerate=self.sample_rate,
                channels=2,
                callback=self._audio_callback,
                blocksize=self.buffer_size
            ):
                while self.is_playing:
                    time.sleep(0.1)
        except Exception as e:
            print(f"Audio playback error: {e}")
    
    def _audio_callback(self, outdata, frames, time_info, status):
        """Audio callback function for real-time playback"""
        if status:
            print(f"Audio status: {status}")
        
        # Initialize output buffer
        outdata.fill(0)
        
        # Mix all active layers
        layers_to_remove = []
        
        for layer_id, layer in self.active_layers.items():
            audio_data = layer['data']
            position = layer['position']
            
            # Check if layer is finished
            if position >= len(audio_data):
                layers_to_remove.append(layer_id)
                continue
            
            # Calculate how many samples to copy
            samples_available = len(audio_data) - position
            samples_needed = min(frames, samples_available)
            
            # Copy audio data to output buffer
            if samples_needed > 0:
                outdata[:samples_needed] += audio_data[position:position + samples_needed] * self.master_volume
                layer['position'] += samples_needed
        
        # Remove finished layers
        for layer_id in layers_to_remove:
            del self.active_layers[layer_id]
    
    def get_system_status(self) -> Dict:
        """Get current audio engine status"""
        return {
            'is_playing': self.is_playing,
            'active_layers': len(self.active_layers),
            'master_volume': self.master_volume,
            'sample_rate': self.sample_rate,
            'audio_available': AUDIO_AVAILABLE
        }

# Example usage and testing
if __name__ == "__main__":
    print("🎵 Orion Protocol Audio Engine Test")
    print("=" * 40)
    
    # Create audio engine
    engine = AudioEngine()
    engine.start_engine()
    
    try:
        # Test 432Hz tone
        print("Playing 432Hz harmonic tone...")
        layer1 = engine.play_tone(432.0, duration=2.0, mode=AudioMode.HARMONIC)
        time.sleep(2.5)
        
        # Test chord progression
        print("Playing 432Hz major chord...")
        layer2 = engine.play_chord(432.0, 'major', duration=3.0)
        time.sleep(3.5)
        
        # Test binaural beats
        print("Playing binaural beats (432Hz + 10Hz)...")
        layer3 = engine.play_binaural_beat(432.0, 10.0, duration=5.0)
        time.sleep(2.0)
        
        # Test market audio
        print("Testing market-driven audio...")
        market_audio = engine.create_market_audio(75.0, 'RSI', intensity=0.8)
        print(f"Generated frequency: {market_audio['frequency']:.1f} Hz")
        time.sleep(2.0)
        
        # Test biometric audio
        print("Testing biometric audio...")
        bio_audio = engine.create_biometric_audio(85.0, stress_level=0.3)
        print(f"Heart frequency: {bio_audio['heart_frequency']:.1f} Hz")
        time.sleep(3.0)
        
        # Show status
        status = engine.get_system_status()
        print(f"\nEngine Status: {status}")
        
    except KeyboardInterrupt:
        print("\nStopping audio engine...")
    
    finally:
        engine.stop_engine()
        print("Audio engine stopped.")

