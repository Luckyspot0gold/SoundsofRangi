#!/usr/bin/env python3
"""
Market Sensory System for Orion Protocol

This module implements sophisticated market indicator analysis and converts
financial data into multi-sensory experiences through animations, audio,
and vibration patterns. It supports various technical indicators and
provides intelligent mapping to sensory outputs.

The system is designed to make complex market data immediately intuitive
through embodied cognition principles.
"""

import numpy as np
import json
import time
from typing import Dict, List, Tuple, Optional, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta

class IndicatorType(Enum):
    """Types of market indicators supported"""
    RSI = "RSI"                    # Relative Strength Index
    MACD = "MACD"                  # Moving Average Convergence Divergence
    BOLLINGER = "BOLLINGER"        # Bollinger Bands
    STOCHASTIC = "STOCHASTIC"      # Stochastic Oscillator
    VOLUME = "VOLUME"              # Volume indicators
    PRICE = "PRICE"                # Price movement
    MOMENTUM = "MOMENTUM"          # Momentum indicators
    VOLATILITY = "VOLATILITY"      # Volatility measures

class AnimationType(Enum):
    """Types of animations available"""
    BOXER_JAB = "boxer_jab"
    BOXER_CROSS = "boxer_cross"
    BOXER_HOOK = "boxer_hook"
    BOXER_UPPERCUT = "boxer_uppercut"
    BOXER_DODGE = "boxer_dodge"
    BOXER_BLOCK = "boxer_block"
    BOXER_COMBO = "boxer_combo"
    BOXER_VICTORY = "boxer_victory"
    BOXER_DEFEAT = "boxer_defeat"
    
    RACER_ACCELERATE = "racer_accelerate"
    RACER_BRAKE = "racer_brake"
    RACER_TURN_LEFT = "racer_turn_left"
    RACER_TURN_RIGHT = "racer_turn_right"
    RACER_DRIFT = "racer_drift"
    RACER_BOOST = "racer_boost"
    RACER_CRASH = "racer_crash"
    RACER_VICTORY = "racer_victory"

class VibrationPattern(Enum):
    """Types of vibration patterns"""
    PULSE = "pulse"
    WAVE = "wave"
    BURST = "burst"
    RHYTHM = "rhythm"
    HEARTBEAT = "heartbeat"
    BREATHING = "breathing"
    IMPACT = "impact"
    SUSTAINED = "sustained"

@dataclass
class SensoryOutput:
    """Complete sensory output for a market event"""
    animation: AnimationType
    audio_frequency: float
    audio_amplitude: float
    audio_duration: float
    vibration_pattern: VibrationPattern
    vibration_intensity: float
    vibration_duration: float
    color_scheme: Dict[str, str] = field(default_factory=dict)
    effects: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class MarketEvent:
    """Represents a market event with context"""
    indicator: IndicatorType
    value: float
    previous_value: float
    timestamp: datetime
    symbol: str
    timeframe: str
    significance: float  # 0.0 to 1.0
    trend_direction: str  # 'up', 'down', 'sideways'
    volatility: float
    volume_ratio: float = 1.0

class TechnicalIndicators:
    """
    Calculates various technical indicators from market data
    
    This class provides methods to compute common technical indicators
    used in financial analysis and trading.
    """
    
    @staticmethod
    def calculate_rsi(prices: List[float], period: int = 14) -> float:
        """
        Calculate Relative Strength Index (RSI)
        
        Args:
            prices: List of closing prices
            period: RSI calculation period
            
        Returns:
            RSI value (0-100)
        """
        if len(prices) < period + 1:
            return 50.0  # Neutral RSI
        
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        
        if avg_loss == 0:
            return 100.0
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    @staticmethod
    def calculate_macd(prices: List[float], fast: int = 12, slow: int = 26, 
                      signal: int = 9) -> Tuple[float, float, float]:
        """
        Calculate MACD (Moving Average Convergence Divergence)
        
        Args:
            prices: List of closing prices
            fast: Fast EMA period
            slow: Slow EMA period
            signal: Signal line EMA period
            
        Returns:
            Tuple of (MACD line, Signal line, Histogram)
        """
        if len(prices) < slow:
            return 0.0, 0.0, 0.0
        
        prices_array = np.array(prices)
        
        # Calculate EMAs
        ema_fast = TechnicalIndicators._calculate_ema(prices_array, fast)
        ema_slow = TechnicalIndicators._calculate_ema(prices_array, slow)
        
        # MACD line
        macd_line = ema_fast[-1] - ema_slow[-1]
        
        # For signal line, we need MACD history
        if len(prices) < slow + signal:
            return macd_line, 0.0, macd_line
        
        macd_history = ema_fast[slow-1:] - ema_slow[slow-1:]
        signal_line = TechnicalIndicators._calculate_ema(macd_history, signal)[-1]
        
        histogram = macd_line - signal_line
        
        return macd_line, signal_line, histogram
    
    @staticmethod
    def calculate_bollinger_bands(prices: List[float], period: int = 20, 
                                 std_dev: float = 2.0) -> Tuple[float, float, float]:
        """
        Calculate Bollinger Bands
        
        Args:
            prices: List of closing prices
            period: Moving average period
            std_dev: Standard deviation multiplier
            
        Returns:
            Tuple of (Upper band, Middle band, Lower band)
        """
        if len(prices) < period:
            current_price = prices[-1] if prices else 0.0
            return current_price, current_price, current_price
        
        recent_prices = prices[-period:]
        middle_band = np.mean(recent_prices)
        std = np.std(recent_prices)
        
        upper_band = middle_band + (std_dev * std)
        lower_band = middle_band - (std_dev * std)
        
        return upper_band, middle_band, lower_band
    
    @staticmethod
    def calculate_stochastic(highs: List[float], lows: List[float], 
                           closes: List[float], k_period: int = 14,
                           d_period: int = 3) -> Tuple[float, float]:
        """
        Calculate Stochastic Oscillator
        
        Args:
            highs: List of high prices
            lows: List of low prices
            closes: List of closing prices
            k_period: %K calculation period
            d_period: %D smoothing period
            
        Returns:
            Tuple of (%K, %D)
        """
        if len(closes) < k_period:
            return 50.0, 50.0
        
        recent_highs = highs[-k_period:]
        recent_lows = lows[-k_period:]
        current_close = closes[-1]
        
        highest_high = max(recent_highs)
        lowest_low = min(recent_lows)
        
        if highest_high == lowest_low:
            k_percent = 50.0
        else:
            k_percent = ((current_close - lowest_low) / (highest_high - lowest_low)) * 100
        
        # For %D, we need %K history
        if len(closes) < k_period + d_period:
            return k_percent, k_percent
        
        # Calculate %K for the last d_period days
        k_values = []
        for i in range(d_period):
            idx = -(i + 1)
            period_highs = highs[idx - k_period + 1:idx + 1]
            period_lows = lows[idx - k_period + 1:idx + 1]
            period_close = closes[idx]
            
            period_highest = max(period_highs)
            period_lowest = min(period_lows)
            
            if period_highest == period_lowest:
                k_val = 50.0
            else:
                k_val = ((period_close - period_lowest) / (period_highest - period_lowest)) * 100
            
            k_values.append(k_val)
        
        d_percent = np.mean(k_values)
        
        return k_percent, d_percent
    
    @staticmethod
    def _calculate_ema(prices: np.ndarray, period: int) -> np.ndarray:
        """Calculate Exponential Moving Average"""
        alpha = 2.0 / (period + 1)
        ema = np.zeros_like(prices)
        ema[0] = prices[0]
        
        for i in range(1, len(prices)):
            ema[i] = alpha * prices[i] + (1 - alpha) * ema[i - 1]
        
        return ema

class MarketSensorySystem:
    """
    Main class that converts market indicators into sensory experiences
    
    This system analyzes market data and generates appropriate animations,
    audio frequencies, and vibration patterns based on the current market
    conditions and technical indicators.
    """
    
    def __init__(self, base_frequency: float = 432.0):
        self.base_frequency = base_frequency
        self.indicators = TechnicalIndicators()
        
        # Initialize mapping systems
        self.animation_maps = self._initialize_animation_maps()
        self.audio_maps = self._initialize_audio_maps()
        self.vibration_maps = self._initialize_vibration_maps()
        
        # Market state tracking
        self.market_history = {}
        self.current_trends = {}
        self.volatility_cache = {}
        
        # Sensory output cache
        self.output_cache = {}
        self.cache_duration = 1.0  # seconds
    
    def process_market_data(self, symbol: str, prices: List[float], 
                           volumes: List[float] = None, 
                           highs: List[float] = None,
                           lows: List[float] = None) -> Dict[str, SensoryOutput]:
        """
        Process market data and generate sensory outputs for all indicators
        
        Args:
            symbol: Trading symbol (e.g., 'BTC-USD')
            prices: List of closing prices
            volumes: List of trading volumes (optional)
            highs: List of high prices (optional)
            lows: List of low prices (optional)
            
        Returns:
            Dictionary mapping indicator names to sensory outputs
        """
        if len(prices) < 2:
            return {}
        
        # Use prices for highs/lows if not provided
        if highs is None:
            highs = prices.copy()
        if lows is None:
            lows = prices.copy()
        if volumes is None:
            volumes = [1.0] * len(prices)
        
        current_time = datetime.now()
        results = {}
        
        # Calculate all indicators
        indicators_data = self._calculate_all_indicators(prices, volumes, highs, lows)
        
        # Generate sensory outputs for each indicator
        for indicator_type, value in indicators_data.items():
            if indicator_type in self.market_history.get(symbol, {}):
                previous_value = self.market_history[symbol][indicator_type]
            else:
                previous_value = value
            
            # Create market event
            market_event = MarketEvent(
                indicator=indicator_type,
                value=value,
                previous_value=previous_value,
                timestamp=current_time,
                symbol=symbol,
                timeframe='1m',  # Default timeframe
                significance=self._calculate_significance(indicator_type, value, previous_value),
                trend_direction=self._determine_trend(value, previous_value),
                volatility=self._calculate_volatility(prices[-10:]),  # Last 10 periods
                volume_ratio=volumes[-1] / np.mean(volumes[-10:]) if len(volumes) >= 10 else 1.0
            )
            
            # Generate sensory output
            sensory_output = self.convert_to_sensory_output(market_event)
            results[indicator_type.value] = sensory_output
        
        # Update market history
        if symbol not in self.market_history:
            self.market_history[symbol] = {}
        
        for indicator_type, value in indicators_data.items():
            self.market_history[symbol][indicator_type] = value
        
        return results
    
    def convert_to_sensory_output(self, market_event: MarketEvent) -> SensoryOutput:
        """
        Convert a market event into a complete sensory output
        
        Args:
            market_event: Market event to convert
            
        Returns:
            Complete sensory output specification
        """
        indicator = market_event.indicator
        value = market_event.value
        
        # Get mappings for this indicator
        animation_func = self.animation_maps.get(indicator, self._default_animation_map)
        audio_func = self.audio_maps.get(indicator, self._default_audio_map)
        vibration_func = self.vibration_maps.get(indicator, self._default_vibration_map)
        
        # Generate outputs
        animation = animation_func(market_event)
        audio_data = audio_func(market_event)
        vibration_data = vibration_func(market_event)
        
        # Create color scheme based on trend and significance
        color_scheme = self._generate_color_scheme(market_event)
        
        # Generate visual effects
        effects = self._generate_effects(market_event)
        
        # Create metadata
        metadata = {
            'indicator': indicator.value,
            'value': value,
            'previous_value': market_event.previous_value,
            'change': value - market_event.previous_value,
            'change_percent': ((value - market_event.previous_value) / market_event.previous_value * 100) 
                             if market_event.previous_value != 0 else 0,
            'significance': market_event.significance,
            'trend': market_event.trend_direction,
            'volatility': market_event.volatility,
            'timestamp': market_event.timestamp.isoformat()
        }
        
        return SensoryOutput(
            animation=animation,
            audio_frequency=audio_data['frequency'],
            audio_amplitude=audio_data['amplitude'],
            audio_duration=audio_data['duration'],
            vibration_pattern=vibration_data['pattern'],
            vibration_intensity=vibration_data['intensity'],
            vibration_duration=vibration_data['duration'],
            color_scheme=color_scheme,
            effects=effects,
            metadata=metadata
        )
    
    def _calculate_all_indicators(self, prices: List[float], volumes: List[float],
                                 highs: List[float], lows: List[float]) -> Dict[IndicatorType, float]:
        """Calculate all supported technical indicators"""
        results = {}
        
        # RSI
        rsi = self.indicators.calculate_rsi(prices)
        results[IndicatorType.RSI] = rsi
        
        # MACD
        macd_line, signal_line, histogram = self.indicators.calculate_macd(prices)
        results[IndicatorType.MACD] = histogram  # Use histogram for sensory output
        
        # Bollinger Bands - use position relative to bands
        upper, middle, lower = self.indicators.calculate_bollinger_bands(prices)
        current_price = prices[-1]
        if upper != lower:
            bb_position = (current_price - lower) / (upper - lower) * 100
        else:
            bb_position = 50.0
        results[IndicatorType.BOLLINGER] = bb_position
        
        # Stochastic
        k_percent, d_percent = self.indicators.calculate_stochastic(highs, lows, prices)
        results[IndicatorType.STOCHASTIC] = k_percent
        
        # Volume (relative to average)
        if len(volumes) >= 10:
            volume_ratio = volumes[-1] / np.mean(volumes[-10:])
            results[IndicatorType.VOLUME] = volume_ratio
        else:
            results[IndicatorType.VOLUME] = 1.0
        
        # Price momentum (percentage change)
        if len(prices) >= 2:
            price_change = (prices[-1] - prices[-2]) / prices[-2] * 100
            results[IndicatorType.MOMENTUM] = price_change
        else:
            results[IndicatorType.MOMENTUM] = 0.0
        
        # Volatility (standard deviation of recent returns)
        if len(prices) >= 10:
            returns = np.diff(prices[-10:]) / prices[-10:-1]
            volatility = np.std(returns) * 100
            results[IndicatorType.VOLATILITY] = volatility
        else:
            results[IndicatorType.VOLATILITY] = 0.0
        
        return results
    
    def _initialize_animation_maps(self) -> Dict[IndicatorType, Callable]:
        """Initialize animation mapping functions for each indicator"""
        return {
            IndicatorType.RSI: self._rsi_animation_map,
            IndicatorType.MACD: self._macd_animation_map,
            IndicatorType.BOLLINGER: self._bollinger_animation_map,
            IndicatorType.STOCHASTIC: self._stochastic_animation_map,
            IndicatorType.VOLUME: self._volume_animation_map,
            IndicatorType.MOMENTUM: self._momentum_animation_map,
            IndicatorType.VOLATILITY: self._volatility_animation_map
        }
    
    def _initialize_audio_maps(self) -> Dict[IndicatorType, Callable]:
        """Initialize audio mapping functions for each indicator"""
        return {
            IndicatorType.RSI: self._rsi_audio_map,
            IndicatorType.MACD: self._macd_audio_map,
            IndicatorType.BOLLINGER: self._bollinger_audio_map,
            IndicatorType.STOCHASTIC: self._stochastic_audio_map,
            IndicatorType.VOLUME: self._volume_audio_map,
            IndicatorType.MOMENTUM: self._momentum_audio_map,
            IndicatorType.VOLATILITY: self._volatility_audio_map
        }
    
    def _initialize_vibration_maps(self) -> Dict[IndicatorType, Callable]:
        """Initialize vibration mapping functions for each indicator"""
        return {
            IndicatorType.RSI: self._rsi_vibration_map,
            IndicatorType.MACD: self._macd_vibration_map,
            IndicatorType.BOLLINGER: self._bollinger_vibration_map,
            IndicatorType.STOCHASTIC: self._stochastic_vibration_map,
            IndicatorType.VOLUME: self._volume_vibration_map,
            IndicatorType.MOMENTUM: self._momentum_vibration_map,
            IndicatorType.VOLATILITY: self._volatility_vibration_map
        }
    
    # RSI Mappings
    def _rsi_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map RSI values to animations"""
        rsi = event.value
        
        if rsi > 80:
            return AnimationType.BOXER_VICTORY  # Extremely overbought
        elif rsi > 70:
            return AnimationType.BOXER_UPPERCUT  # Overbought
        elif rsi > 60:
            return AnimationType.BOXER_HOOK  # Strong
        elif rsi > 40:
            return AnimationType.BOXER_JAB  # Neutral
        elif rsi > 30:
            return AnimationType.BOXER_DODGE  # Weak
        elif rsi > 20:
            return AnimationType.BOXER_BLOCK  # Oversold
        else:
            return AnimationType.BOXER_DEFEAT  # Extremely oversold
    
    def _rsi_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        """Map RSI values to audio parameters"""
        rsi = event.value
        
        # Map RSI (0-100) to frequency range around 432Hz
        frequency_offset = (rsi - 50) / 50 * 100  # ±100 Hz
        frequency = self.base_frequency + frequency_offset
        
        # Amplitude based on how extreme the RSI is
        extremeness = abs(rsi - 50) / 50
        amplitude = 0.2 + extremeness * 0.3
        
        # Duration based on significance
        duration = 0.5 + event.significance * 1.5
        
        return {
            'frequency': frequency,
            'amplitude': amplitude,
            'duration': duration
        }
    
    def _rsi_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        """Map RSI values to vibration parameters"""
        rsi = event.value
        
        if rsi > 70 or rsi < 30:
            # Extreme RSI - strong vibration
            pattern = VibrationPattern.BURST
            intensity = 0.7 + (abs(rsi - 50) / 50) * 0.3
        else:
            # Normal RSI - gentle vibration
            pattern = VibrationPattern.PULSE
            intensity = 0.3 + (abs(rsi - 50) / 50) * 0.4
        
        duration = 1.0 + event.significance * 2.0
        
        return {
            'pattern': pattern,
            'intensity': intensity,
            'duration': duration
        }
    
    # MACD Mappings
    def _macd_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map MACD histogram to animations"""
        histogram = event.value
        
        if histogram > 0.5:
            return AnimationType.BOXER_UPPERCUT
        elif histogram > 0.1:
            return AnimationType.BOXER_HOOK
        elif histogram > 0:
            return AnimationType.BOXER_JAB
        elif histogram > -0.1:
            return AnimationType.BOXER_DODGE
        elif histogram > -0.5:
            return AnimationType.BOXER_BLOCK
        else:
            return AnimationType.BOXER_DEFEAT
    
    def _macd_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        """Map MACD to audio parameters"""
        histogram = event.value
        
        # MACD can be positive or negative
        frequency_offset = np.clip(histogram * 50, -200, 200)
        frequency = self.base_frequency + frequency_offset
        
        amplitude = 0.3 + min(abs(histogram), 1.0) * 0.4
        duration = 1.0 + event.significance * 1.0
        
        return {
            'frequency': frequency,
            'amplitude': amplitude,
            'duration': duration
        }
    
    def _macd_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        """Map MACD to vibration parameters"""
        histogram = event.value
        
        if histogram > 0:
            pattern = VibrationPattern.WAVE  # Smooth upward movement
        else:
            pattern = VibrationPattern.PULSE  # Choppy downward movement
        
        intensity = 0.2 + min(abs(histogram), 1.0) * 0.6
        duration = 1.5
        
        return {
            'pattern': pattern,
            'intensity': intensity,
            'duration': duration
        }
    
    # Volume Mappings
    def _volume_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map volume to animations"""
        volume_ratio = event.value
        
        if volume_ratio > 3.0:
            return AnimationType.BOXER_COMBO  # Massive volume
        elif volume_ratio > 2.0:
            return AnimationType.BOXER_UPPERCUT  # High volume
        elif volume_ratio > 1.5:
            return AnimationType.BOXER_HOOK  # Above average
        elif volume_ratio > 0.5:
            return AnimationType.BOXER_JAB  # Normal volume
        else:
            return AnimationType.BOXER_DODGE  # Low volume
    
    def _volume_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        """Map volume to audio parameters"""
        volume_ratio = event.value
        
        # Higher volume = higher amplitude, not frequency
        frequency = self.base_frequency
        amplitude = 0.1 + min(volume_ratio / 3.0, 1.0) * 0.6
        duration = 0.5 + min(volume_ratio / 2.0, 1.0) * 1.0
        
        return {
            'frequency': frequency,
            'amplitude': amplitude,
            'duration': duration
        }
    
    def _volume_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        """Map volume to vibration parameters"""
        volume_ratio = event.value
        
        if volume_ratio > 2.0:
            pattern = VibrationPattern.IMPACT  # Sharp, strong vibration
            intensity = 0.8
        elif volume_ratio > 1.5:
            pattern = VibrationPattern.BURST
            intensity = 0.6
        else:
            pattern = VibrationPattern.PULSE
            intensity = 0.3
        
        duration = 0.5 + min(volume_ratio / 2.0, 1.0) * 1.0
        
        return {
            'pattern': pattern,
            'intensity': intensity,
            'duration': duration
        }
    
    # Default mappings for other indicators
    def _bollinger_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map Bollinger Band position to animations"""
        position = event.value  # 0-100 position within bands
        
        if position > 90:
            return AnimationType.BOXER_UPPERCUT  # Near upper band
        elif position > 70:
            return AnimationType.BOXER_HOOK
        elif position > 30:
            return AnimationType.BOXER_JAB  # Middle of bands
        elif position > 10:
            return AnimationType.BOXER_DODGE
        else:
            return AnimationType.BOXER_BLOCK  # Near lower band
    
    def _stochastic_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map Stochastic %K to animations"""
        k_percent = event.value
        
        if k_percent > 80:
            return AnimationType.BOXER_VICTORY
        elif k_percent > 60:
            return AnimationType.BOXER_UPPERCUT
        elif k_percent > 40:
            return AnimationType.BOXER_JAB
        elif k_percent > 20:
            return AnimationType.BOXER_DODGE
        else:
            return AnimationType.BOXER_DEFEAT
    
    def _momentum_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map price momentum to animations"""
        momentum = event.value  # Percentage change
        
        if momentum > 5:
            return AnimationType.BOXER_UPPERCUT
        elif momentum > 2:
            return AnimationType.BOXER_HOOK
        elif momentum > 0:
            return AnimationType.BOXER_JAB
        elif momentum > -2:
            return AnimationType.BOXER_DODGE
        elif momentum > -5:
            return AnimationType.BOXER_BLOCK
        else:
            return AnimationType.BOXER_DEFEAT
    
    def _volatility_animation_map(self, event: MarketEvent) -> AnimationType:
        """Map volatility to animations"""
        volatility = event.value
        
        if volatility > 5:
            return AnimationType.BOXER_COMBO  # High volatility = combo moves
        elif volatility > 3:
            return AnimationType.BOXER_HOOK
        elif volatility > 1:
            return AnimationType.BOXER_JAB
        else:
            return AnimationType.BOXER_DODGE  # Low volatility = defensive
    
    # Default audio mappings
    def _bollinger_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        return self._default_audio_map(event)
    
    def _stochastic_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        return self._default_audio_map(event)
    
    def _momentum_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        return self._default_audio_map(event)
    
    def _volatility_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        return self._default_audio_map(event)
    
    # Default vibration mappings
    def _bollinger_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        return self._default_vibration_map(event)
    
    def _stochastic_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        return self._default_vibration_map(event)
    
    def _momentum_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        return self._default_vibration_map(event)
    
    def _volatility_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        return self._default_vibration_map(event)
    
    # Default mapping functions
    def _default_animation_map(self, event: MarketEvent) -> AnimationType:
        """Default animation mapping"""
        if event.trend_direction == 'up':
            return AnimationType.BOXER_UPPERCUT
        elif event.trend_direction == 'down':
            return AnimationType.BOXER_DODGE
        else:
            return AnimationType.BOXER_JAB
    
    def _default_audio_map(self, event: MarketEvent) -> Dict[str, float]:
        """Default audio mapping"""
        return {
            'frequency': self.base_frequency,
            'amplitude': 0.3,
            'duration': 1.0
        }
    
    def _default_vibration_map(self, event: MarketEvent) -> Dict[str, Any]:
        """Default vibration mapping"""
        return {
            'pattern': VibrationPattern.PULSE,
            'intensity': 0.3,
            'duration': 1.0
        }
    
    # Helper methods
    def _calculate_significance(self, indicator: IndicatorType, value: float, 
                              previous_value: float) -> float:
        """Calculate the significance of a market event (0.0 to 1.0)"""
        change = abs(value - previous_value)
        
        # Significance thresholds for different indicators
        thresholds = {
            IndicatorType.RSI: 10.0,      # RSI change of 10 points
            IndicatorType.MACD: 0.5,      # MACD histogram change
            IndicatorType.BOLLINGER: 20.0, # Bollinger position change
            IndicatorType.STOCHASTIC: 15.0, # Stochastic change
            IndicatorType.VOLUME: 1.0,     # Volume ratio change
            IndicatorType.MOMENTUM: 2.0,   # 2% price change
            IndicatorType.VOLATILITY: 1.0  # 1% volatility change
        }
        
        threshold = thresholds.get(indicator, 1.0)
        significance = min(change / threshold, 1.0)
        
        return significance
    
    def _determine_trend(self, value: float, previous_value: float) -> str:
        """Determine trend direction"""
        if value > previous_value * 1.001:  # 0.1% threshold
            return 'up'
        elif value < previous_value * 0.999:
            return 'down'
        else:
            return 'sideways'
    
    def _calculate_volatility(self, prices: List[float]) -> float:
        """Calculate volatility from price series"""
        if len(prices) < 2:
            return 0.0
        
        returns = np.diff(prices) / prices[:-1]
        return np.std(returns) * 100
    
    def _generate_color_scheme(self, event: MarketEvent) -> Dict[str, str]:
        """Generate color scheme based on market event"""
        if event.trend_direction == 'up':
            primary = '#00ff88'  # Green
            secondary = '#88ffaa'
        elif event.trend_direction == 'down':
            primary = '#ff4444'  # Red
            secondary = '#ff8888'
        else:
            primary = '#ffaa00'  # Orange
            secondary = '#ffcc44'
        
        # Intensity based on significance
        intensity = int(255 * event.significance)
        accent = f'#{intensity:02x}{intensity:02x}ff'
        
        return {
            'primary': primary,
            'secondary': secondary,
            'accent': accent,
            'background': '#1a1a2e'
        }
    
    def _generate_effects(self, event: MarketEvent) -> List[str]:
        """Generate visual effects based on market event"""
        effects = []
        
        if event.significance > 0.8:
            effects.append('screen_shake')
            effects.append('particle_burst')
        elif event.significance > 0.5:
            effects.append('glow_effect')
            effects.append('ripple')
        
        if event.volatility > 3.0:
            effects.append('lightning')
        
        if event.volume_ratio > 2.0:
            effects.append('volume_bars')
        
        return effects
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get current system status"""
        return {
            'base_frequency': self.base_frequency,
            'tracked_symbols': list(self.market_history.keys()),
            'cache_size': len(self.output_cache),
            'supported_indicators': [indicator.value for indicator in IndicatorType],
            'animation_types': [anim.value for anim in AnimationType],
            'vibration_patterns': [pattern.value for pattern in VibrationPattern]
        }

# Example usage and testing
if __name__ == "__main__":
    print("📊 Market Sensory System Test")
    print("=" * 40)
    
    # Create market sensory system
    system = MarketSensorySystem()
    
    # Generate sample market data
    np.random.seed(42)
    base_price = 50000  # Bitcoin price
    prices = [base_price]
    
    # Simulate 50 price movements
    for i in range(50):
        change = np.random.normal(0, 0.02)  # 2% volatility
        new_price = prices[-1] * (1 + change)
        prices.append(new_price)
    
    # Generate volumes (random but correlated with price changes)
    volumes = []
    for i in range(len(prices)):
        if i == 0:
            volumes.append(1000000)
        else:
            price_change = abs(prices[i] - prices[i-1]) / prices[i-1]
            volume_multiplier = 1 + price_change * 5  # Higher volume with bigger moves
            base_volume = 1000000 * np.random.uniform(0.5, 1.5)
            volumes.append(base_volume * volume_multiplier)
    
    # Process market data
    print("Processing market data...")
    results = system.process_market_data('BTC-USD', prices, volumes)
    
    # Display results
    print(f"\nGenerated sensory outputs for {len(results)} indicators:")
    print("-" * 60)
    
    for indicator_name, output in results.items():
        print(f"\n{indicator_name}:")
        print(f"  Animation: {output.animation.value}")
        print(f"  Audio: {output.audio_frequency:.1f} Hz, {output.audio_amplitude:.2f} amplitude")
        print(f"  Vibration: {output.vibration_pattern.value}, {output.vibration_intensity:.2f} intensity")
        print(f"  Effects: {', '.join(output.effects) if output.effects else 'None'}")
        print(f"  Significance: {output.metadata['significance']:.2f}")
        print(f"  Trend: {output.metadata['trend']}")
    
    # Test individual indicator
    print(f"\n" + "=" * 60)
    print("Testing RSI-specific output...")
    
    # Calculate RSI for the price series
    rsi_value = system.indicators.calculate_rsi(prices)
    print(f"Current RSI: {rsi_value:.1f}")
    
    # Create a market event
    from datetime import datetime
    market_event = MarketEvent(
        indicator=IndicatorType.RSI,
        value=rsi_value,
        previous_value=50.0,
        timestamp=datetime.now(),
        symbol='BTC-USD',
        timeframe='1h',
        significance=0.7,
        trend_direction='up' if rsi_value > 50 else 'down',
        volatility=2.5,
        volume_ratio=1.2
    )
    
    # Generate sensory output
    rsi_output = system.convert_to_sensory_output(market_event)
    
    print(f"RSI Sensory Output:")
    print(f"  Animation: {rsi_output.animation.value}")
    print(f"  Audio: {rsi_output.audio_frequency:.1f} Hz")
    print(f"  Vibration: {rsi_output.vibration_pattern.value}")
    print(f"  Color Scheme: {rsi_output.color_scheme}")
    
    # Show system status
    status = system.get_system_status()
    print(f"\nSystem Status:")
    print(f"  Base Frequency: {status['base_frequency']} Hz")
    print(f"  Supported Indicators: {len(status['supported_indicators'])}")
    print(f"  Animation Types: {len(status['animation_types'])}")
    print(f"  Vibration Patterns: {len(status['vibration_patterns'])}")
    
    print("\n✅ Market Sensory System test completed!")

